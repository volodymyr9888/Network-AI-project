import argparse
import os
from pathlib import Path
import subprocess
import sys

parser=argparse.ArgumentParser(description='Start a live simulation with explicit forecasting and warning models')
parser.add_argument('--model',choices=['tirex','chronos','persistence'],default='tirex')
parser.add_argument('--device',choices=['cpu','cuda','auto'],default='cpu')
parser.add_argument('--cause',choices=['interference','power','load'],default='interference')
parser.add_argument('--warning',choices=['none','logistic','forest'],default='none')
parser.add_argument('--artifacts',type=Path,default=Path('models/warnings'))
parser.add_argument('--port',type=int,default=8766)
parser.add_argument('--seed',type=int,default=0)
parser.add_argument('--headless',action='store_true')
args=parser.parse_args()
if not 1024<=args.port<=65535:parser.error('Port must be 1024–65535')
env=os.environ.copy()
env.update(NETWORK_AI_MODEL=args.model,NETWORK_AI_DEVICE=args.device,NETWORK_AI_CAUSE=args.cause,
           NETWORK_AI_PORT=str(args.port),NETWORK_AI_SEED=str(args.seed),NETWORK_AI_PYTHON=sys.executable,
           NETWORK_AI_UI='Cmdenv' if args.headless else 'Qtenv')
env.pop('NETWORK_AI_WARNING_MODEL',None)
if args.warning!='none':
    artifact=(args.artifacts/f'{args.warning}.json').resolve()
    if not artifact.is_file():parser.error('Warning model missing. Run lab train first or use --warning none.')
    env['NETWORK_AI_WARNING_MODEL']=str(artifact)
raise SystemExit(subprocess.call(['bash',str(Path(__file__).with_name('run_live.sh'))],env=env))
