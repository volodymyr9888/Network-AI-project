"""Evaluate identical target pairs; availability is in received simulation seconds."""


def evaluate_horizons(observed, forecasts):
    actual = dict(observed)
    result = []
    for horizon in (1, 3, 5):
        pairs = []
        for forecast in forecasts:
            target = forecast['issued_at'] + horizon
            if target not in actual or target <= 0:
                continue
            available = forecast.get('available_at_s')
            pairs.append((abs(forecast['values'][horizon - 1] - actual[target]),
                          abs(forecast['baseline'] - actual[target]),
                          available is not None and available < target))
        timely = [p for p in pairs if p[2]]
        def mean(rows, index):
            return sum(p[index] for p in rows) / len(rows) if rows else None
        ai, baseline = mean(timely, 0), mean(timely, 1)
        result.append(dict(horizon=horizon, count=len(pairs), timely_count=len(timely),
                           all_mae=mean(pairs, 0), all_baseline_mae=mean(pairs, 1),
                           timely_mae=ai, timely_baseline_mae=baseline,
                           skill_percent=100 * (1 - ai / baseline)
                           if baseline is not None and baseline > 0 else None))
    return result


def evaluate_alerts(measurements, forecasts):
    """Per-target warning confusion counts; warning threshold uses only origin-time load."""
    rows = {r[0]: r for r in measurements}
    scores = []
    for horizon in (1, 3, 5):
        counts = dict(tp=0, fp=0, fn=0, tn=0)
        for f in forecasts:
            target = f['issued_at'] + horizon
            origin_row, target_row = rows.get(f['issued_at']), rows.get(target)
            if (origin_row is None or target_row is None or f.get('available_at_s') is None
                    or f['available_at_s'] >= target):
                continue
            offered, future_offered = origin_row[2], target_row[2]
            if offered is None or future_offered is None or offered <= 0 or future_offered <= 0:
                continue
            warning = f['values'][horizon-1] < .5 * offered
            degraded = target_row[1] < .5 * future_offered
            counts['tp' if warning and degraded else 'fp' if warning else 'fn' if degraded else 'tn'] += 1
        scores.append(dict(horizon=horizon, **counts))
    return scores
