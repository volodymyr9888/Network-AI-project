"""Common, past-only model interface for live and repeatable offline evaluation."""
import importlib.metadata
import math
import platform
import os
from pathlib import Path
import numpy as np
import torch

MODELS = ('tirex', 'chronos', 'persistence')


class Predictor:
    def __init__(self, name='tirex', device='cpu', offline=False, use_covariates=True):
        if name not in MODELS or device not in ('cpu', 'cuda', 'auto'):
            raise ValueError('Unsupported model/device')
        self.name = name
        self.device = ('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else device
        if self.device == 'cuda' and not torch.cuda.is_available():
            raise RuntimeError('CUDA unavailable. Install CUDA PyTorch and check the NVIDIA driver, or use --device cpu.')
        if name == 'persistence':
            self.device = 'cpu'
        self.use_covariates = use_covariates and name != 'persistence'
        torch.set_num_threads(4)
        self.model_id = {'tirex': 'NX-AI/TiRex-2', 'chronos': 'amazon/chronos-2',
                         'persistence': 'last-value'}[name]
        self.revision = os.environ.get('NETWORK_AI_MODEL_REVISION', 'main')
        if name == 'tirex':
            if self.device == 'cuda' and torch.cuda.get_device_capability(0)[0] < 8:
                raise RuntimeError('This adapter requires NVIDIA Ampere or newer for TiRex CUDA. '
                                   'On GTX 1650 Ti use TiRex CPU or Chronos CUDA; no silent CPU fallback.')
            from tirex2 import load_model
            self.model = load_model(self.model_id, device=self.device,
                                    hf_kwargs={'local_files_only': offline, 'revision': self.revision})
            raw_quantiles = self.model.quantiles
            quantiles = raw_quantiles.detach().cpu().numpy() if torch.is_tensor(raw_quantiles) else np.asarray(raw_quantiles)
            self.median = int(np.argmin(abs(quantiles - .5)))
            if not np.isclose(quantiles[self.median], .5):
                raise ValueError('Model lacks median quantile')
        elif name == 'chronos':
            from chronos import Chronos2Pipeline
            self.model = Chronos2Pipeline.from_pretrained(self.model_id, device_map=self.device,
                torch_dtype=torch.float32, local_files_only=offline, revision=self.revision)

    def synchronize(self):
        if self.device == 'cuda':
            torch.cuda.synchronize()

    def __call__(self, context, past_covariates=None):
        if len(context) != 128 or not all(math.isfinite(v) for v in context):
            raise ValueError('Expected 128 finite past target values')
        if not self.use_covariates:
            past_covariates = None
        if past_covariates is not None:
            past_covariates = torch.as_tensor(past_covariates, dtype=torch.float32)
            if past_covariates.ndim != 2 or past_covariates.shape[1] != 128:
                raise ValueError('Covariates must have shape (features, 128)')
        with torch.inference_mode():
            if self.name == 'persistence':
                values = [context[-1]] * 5
            elif self.name == 'tirex':
                from tirex2 import TimeseriesType
                series = TimeseriesType(target=torch.tensor([context], dtype=torch.float32),
                    past_covariates=past_covariates, future_covariates=None)
                result = np.asarray(self.model.forecast([series], prediction_length=5, output_type='numpy')[0])
                values = result[0, self.median].tolist()
            else:
                item = {'target': np.asarray(context, dtype=np.float32)}
                if past_covariates is not None:
                    item['past_covariates'] = {f'x{i}': row.cpu().numpy()
                                              for i, row in enumerate(past_covariates)}
                quantiles, _ = self.model.predict_quantiles([item], prediction_length=5,
                    quantile_levels=[.5], context_length=128)
                values = quantiles[0][0, :, 0].float().cpu().tolist()
        self.synchronize()  # Include GPU completion in measured latency.
        if len(values) != 5 or not all(math.isfinite(v) for v in values):
            raise ValueError('Invalid model output')
        return values  # Raw output: no clipping to artificially improve metrics.

    def metadata(self):
        resolved_revision = None
        if self.name != 'persistence':
            from huggingface_hub import try_to_load_from_cache
            cached = try_to_load_from_cache(self.model_id, 'config.json', revision=self.revision)
            if isinstance(cached, str):
                resolved_revision = Path(cached).parent.name
        versions = {}
        for name in ('torch', 'numpy', 'tirex-2', 'chronos-forecasting'):
            try:
                versions[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                pass
        return dict(model=self.name, model_id=self.model_id, device=self.device,
                    requested_revision=self.revision, resolved_revision=resolved_revision,
                    covariates=self.use_covariates, python=platform.python_version(), versions=versions,
                    gpu=torch.cuda.get_device_name(0) if self.device == 'cuda' else None,
                    context=128, horizon=5)
