#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ $# -eq 0 ]]; then echo 'Usage: bash run_dashboard.sh path/to/throughput.csv [options]'; exit 2; fi
exec "${NETWORK_AI_PYTHON:-$project_dir/.venv/bin/python}" -E -s "$project_dir/dashboard.py" "$@"
