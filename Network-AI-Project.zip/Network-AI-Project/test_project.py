import json
from pathlib import Path
import tempfile
import unittest
from benchmark import windows
from dashboard import Replay
from model_adapters import Predictor


class ProjectTests(unittest.TestCase):
    def test_windows_never_use_future(self):
        rows = [[i, i * 10, i * 20] for i in range(1, 141)]
        state = dict(measurements=rows)
        tasks = list(windows(state))
        self.assertEqual(len(tasks), 8)
        origin, context, features = tasks[0]
        self.assertEqual(origin, 128)
        self.assertEqual(context[-1], 1280)
        self.assertEqual(features[0][-1], 2560)
        state['measurements'][-1][0] += 1
        with self.assertRaises(ValueError):
            list(windows(state))

    def test_persistence_contract(self):
        p = Predictor('persistence')
        self.assertEqual(p(list(range(128))), [127] * 5)
        self.assertFalse(p.use_covariates)
        with self.assertRaises(ValueError):
            p([1, 2])

    def test_control_run_isolation_and_cause(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'telemetry.csv'
            replay = Replay(path, live=True, scenario='VariableRadio')
            replay.run_id = 123456789123456789
            request = dict(run_id=str(replay.run_id), mode='manual', load=.75,
                           duration=10, cause='transmitter_power_drop')
            replay.set_interference(request)
            self.assertEqual(Path(str(path)+'.control').read_text().split(),
                [str(replay.run_id), '1', '1', '0.75', '10', '1'])
            for key, value in [('run_id','old'), ('cause','bad'), ('load',float('nan')), ('duration',0)]:
                with self.assertRaises(ValueError):
                    replay.set_interference(dict(request, **{key:value}))
            replay.count = 180
            with self.assertRaises(ValueError):
                replay.set_interference(request)

    def test_event_cause_and_late_forecast(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'telemetry.csv'
            replay = Replay(path, live=True, scenario='VariableRadio')
            Path(str(path)+'.events.csv').write_text('9,0,baseline,0.05,0\n9,1,manual,0.05,1,transmitter_power_drop,1\n8,2,manual,1,99\n')
            forecasts = [dict(issued_at=0, available_at_s=1, values=[100, 10, 10, 10, 10]),
                         dict(issued_at=1, available_at_s=2, values=[0]*5)]
            replay.prepared_measurements = [[0, 100, 100]]
            phases, events = replay.interference_events(9, 3, forecasts, [[1,100,100],[2,10,100],[3,100,100]])
            self.assertEqual(len(phases), 2)
            self.assertEqual(events[0]['cause'], 'transmitter_power_drop')
            self.assertEqual(events[0]['predicted_bps'], 10)
            self.assertEqual(events[0]['lead_s'], 1)
            self.assertEqual(events[0]['end_s'], 3)
            self.assertTrue(events[0]['warned'])
            _, events = replay.interference_events(9, 3,
                [dict(issued_at=1, available_at_s=1, values=[60]*5)],
                [[1,100,100],[2,60,1000],[3,1000,1000]])
            self.assertFalse(events[0]['warned'])  # Do not use future demand to fabricate advance warning.


if __name__ == '__main__':
    unittest.main()
