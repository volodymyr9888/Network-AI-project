"""Early-warning protocol v1: predict an onset, not an already ongoing outage."""
import numpy as np
from lab_data import METRICS, validate_state

PROTOCOL = dict(version=1,horizon=5,ratio_threshold=.5,confirmation_seconds=2,
                healthy_seconds=3,feature_seconds=10,context=128)
STATS = ('last','mean','std','slope','delta','missing')
FEATURE_NAMES = [f'{name}:{stat}' for name in METRICS+['delivery_ratio'] for stat in STATS]


def degraded(row):
    return row[2] is not None and row[2] > 0 and row[1] < PROTOCOL['ratio_threshold']*row[2]


def eligible(history):
    return len(history) >= 128 and all(r[2] is not None and r[2] > 0 and not degraded(r)
                                     for r in history[-PROTOCOL['healthy_seconds']:])


def onsets(rows):
    result = []
    i = 0
    while i < len(rows):
        if not degraded(rows[i]):
            i += 1
            continue
        start = i
        while i < len(rows) and degraded(rows[i]):
            i += 1
        if i-start >= PROTOCOL['confirmation_seconds'] and rows[start][0] > 0:
            result.append(rows[start][0])
    return result


def samples(state):
    rows = validate_state(state)
    starts = onsets(rows)
    for end in range(128,len(rows)-PROTOCOL['horizon']):
        history = rows[end-128:end]
        t = history[-1][0]
        if t < 0 or not eligible(history):
            continue
        yield t, history, int(any(t < s <= t+PROTOCOL['horizon'] for s in starts))


def features(history):
    # Deliberately remove timestamp and exclude all scenario/event/control metadata.
    data = np.asarray([[np.nan if v is None else v for v in r[1:]]
                       for r in history[-PROTOCOL['feature_seconds']:]], dtype=float)
    ratio = np.divide(data[:,0], data[:,1], out=np.full(len(data),np.nan), where=data[:,1]>0)
    data = np.column_stack([data,ratio])
    result = []
    for column in data.T:
        valid = np.isfinite(column)
        values = column[valid]
        times = np.arange(len(column))[valid]
        slope = np.polyfit(times,values,1)[0] if len(values)>1 else np.nan
        result.extend([column[-1],float(values.mean()) if len(values) else np.nan,
                       float(values.std()) if len(values) else np.nan,slope,
                       column[-1]-column[0],1-float(valid.mean())])
    return np.asarray(result)


def evaluate(state, records, deadline_adjusted=False):
    """All decision records share the same eligible origins. Offline deadlines are estimates."""
    starts = onsets(validate_state(state))
    origins = [r['issued_at'] for r in records]
    events = [s for s in starts if any(t < s <= t+5 for t in origins)]
    matched, leads = [], []
    for s in events:
        warnings = []
        for r in records:
            available = r.get('available_at_s',r['issued_at'])
            if deadline_adjusted:
                available = r['issued_at'] + r['latency_ms']/1000
            if r['alarm'] and r['issued_at'] < s <= r['issued_at']+5 and available < s:
                warnings.append(s-available)
        if warnings:
            matched.append(s)
            leads.append(max(warnings))
    counts = dict(tp=0,fp=0,fn=0,tn=0)
    false_times = []
    for r in records:
        key = 'tp' if r['alarm'] and r['label'] else 'fp' if r['alarm'] else 'fn' if r['label'] else 'tn'
        counts[key] += 1
        if key == 'fp': false_times.append(r['issued_at'])
    fp_episodes = sum(i == 0 or t > false_times[i-1]+1 for i,t in enumerate(false_times))
    normal_minutes = (counts['fp']+counts['tn'])/60
    return dict(events=len(events),all_confirmed_events=len(starts),detected_events=len(matched),
        missed_onsets=[s for s in events if s not in matched],
        event_recall=len(matched)/len(events) if events else None,
        mean_lead_s=float(np.mean(leads)) if leads else None,
        false_alarm_episodes=fp_episodes,
        false_episodes_per_normal_minute=fp_episodes/normal_minutes if normal_minutes else None,
        precision=counts['tp']/(counts['tp']+counts['fp']) if counts['tp']+counts['fp'] else None,
        decisions=len(records),**counts)
