import copy
import tempfile
import unittest
from pathlib import Path
import numpy as np
from lab_data import dump, fingerprint, load_manifest
from risk_protocol import features, samples, onsets, evaluate
from risk_models import fit, WarningModel


def recording():
    rows = [[t, 100., 100.] + [None]*15 for t in range(-127, 31)]
    for r in rows:
        if 10 <= r[0] <= 15: r[1] = 10.
    return dict(prepared_measurements=rows[:128], measurements=rows[128:])


class WarningTests(unittest.TestCase):
    def test_tree_threshold_keeps_double_precision(self):
        from risk_protocol import PROTOCOL, FEATURE_NAMES
        a=dict(kind='forest',protocol=PROTOCOL,feature_names=FEATURE_NAMES,threshold=.5,
               fill=[0]*len(FEATURE_NAMES),trees=[dict(left=[1,-1,-1],right=[2,-1,-1],
                   feature=[0,-2,-2],threshold=[1.0000001,-2,-2],probability=[.5,0,1])])
        x=np.zeros((1,len(FEATURE_NAMES)));x[0,0]=np.nextafter(np.float32(1),np.float32(2))
        self.assertEqual(WarningModel(a).probabilities(x)[0],1)

    def test_past_only_features_and_healthy_origins(self):
        state = recording()
        tasks = list(samples(state))
        self.assertEqual([t for t,h,y in tasks if y], [5,6,7,8,9])
        self.assertFalse(any(10 <= t <= 17 for t,h,y in tasks))
        h = tasks[0][1]
        shifted = [[r[0]+900] + r[1:] for r in h]
        np.testing.assert_allclose(features(h), features(shifted), equal_nan=True)
        modified = copy.deepcopy(state)
        modified['measurements'][-1][1] = 0
        np.testing.assert_allclose(features(next(samples(modified))[1]),features(h),equal_nan=True)

    def test_confirmation_and_deadlines(self):
        state = recording()
        state['measurements'][-1][1] = 0  # Unconfirmed right-edge drop.
        self.assertEqual(onsets(state['prepared_measurements']+state['measurements']),[10])
        records = [dict(issued_at=t,label=y,alarm=t in (5,9),latency_ms=6000)
                   for t,h,y in samples(state)]
        self.assertEqual(evaluate(state,records)['mean_lead_s'],5)
        self.assertEqual(evaluate(state,records,True)['detected_events'],0)
        for r in records: r['alarm'] = r['issued_at'] in (1,2,4)
        self.assertEqual(evaluate(state,records)['false_alarm_episodes'],2)

    def test_duplicate_manifest_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp); state=recording(); dump(p/'run.json',state)
            entry=dict(path='run.json',seed=1,split='train',sha256=fingerprint(state))
            dump(p/'manifest.json',dict(runs=[entry,dict(entry,split='test')]))
            with self.assertRaisesRegex(ValueError,'Duplicate'):
                load_manifest(p/'manifest.json')

    def test_portable_models_round_trip(self):
        # Numeric classifier fixtures, not synthetic network traces.
        from risk_protocol import FEATURE_NAMES
        rng=np.random.default_rng(41)
        x=rng.normal(size=(80,len(FEATURE_NAMES)))
        y=(x[:,0]>0).astype(int)
        for kind in ('logistic','forest'):
            artifact=fit(kind,x[:50],y[:50],x[50:],y[50:],dict(train=[],validation=[]))
            with tempfile.TemporaryDirectory() as tmp:
                p=Path(tmp)/'model.json';dump(p,artifact)
                np.testing.assert_allclose(WarningModel(p).probabilities(x),WarningModel(artifact).probabilities(x))

    def test_live_warning_uses_current_measurements_and_exports(self):
        from dashboard import Replay
        class FixedWarning:
            threshold=.5
            artifact={'kind':'test'}
            def __call__(self,history):
                self.last_history=history
                return .75
        with tempfile.TemporaryDirectory() as tmp:
            replay=Replay(Path(tmp)/'telemetry.csv',live=True)
            state=recording()
            replay.warning_model=FixedWarning()
            replay.prepared_measurements=state['prepared_measurements']
            replay.measurements=state['measurements'][:9]
            replay.rows=[r[:2] for r in replay.prepared_measurements+replay.measurements]
            replay.count=9
            replay.update_warning()
            self.assertEqual(replay.warning_records[-1]['issued_at'],9)
            self.assertEqual(len(replay.warning_model.last_history),128)
            replay.measurements=state['measurements'][:20]
            replay.count=20
            self.assertEqual(replay.snapshot()['warning_scores']['detected_events'],1)


if __name__=='__main__':unittest.main()
