# Network AI laboratory

Simu5G packet-level 5G simulation → one-second link measurements → forecasting → local Slovak dashboard.
One stationary phone. The AI observes the link; it does not control the network.

**Start here: [QUICKSTART.md](QUICKSTART.md)** — Windows `lab.cmd`, CPU/CUDA setup, bundled simulator recordings,
training, model comparison and live Qtenv. No PowerShell policy changes are needed.

The early-warning laboratory compares logistic regression, random forest, trend/persistence baselines
and TiRex/Chronos forecast-derived warnings on the same held-out runs. It reports detected beginnings,
false alarms, lead time and inference latency. See [EVALUATION.md](EVALUATION.md) for the protocol.
Open the [example comparison report](examples/reference/report.html) to inspect results and warning timelines
before installing models. It is a hardware-specific demo, not a general ranking or proof of reliable fault prediction.

## What works

- Live OMNeT++ Qtenv and browser dashboard, independent telemetry and prediction workers.
- 128 historical samples → next 5 seconds; TiRex-2, Chronos-2 and last-value baseline.
- CPU or NVIDIA CUDA selection, explicit device reporting and errors (no silent fallback).
- External co-channel interference, gNB transmitter power reduction, increased offered traffic.
- Manual controls with next-simulation-second acknowledgement and automatic expiry.
- Simulator event journal, measured degradation episodes and timely forecast assessment.
- Per-horizon accuracy and availability; identical-window offline model benchmark.
- Downloadable full run with telemetry, preparation history, forecasts and model/environment metadata.

**These are measurements of a simulation, not measurements of a physical mobile network.**
The configured cause/location is simulator ground truth, not a learned AI diagnosis.
Power reduction models a transmitter impairment, not walls, weather or physical obstacles.
Increased traffic is a load condition, not electromagnetic interference. Its congestion effect depends on capacity.

## Prerequisites

Linux or Windows with working WSL2 (WSLg for Qtenv); Python 3.12 through
[uv](https://docs.astral.sh/uv/getting-started/installation/); Git;
[opp_env](https://github.com/omnetpp/opp_env).

Install the simulator stack in a Linux filesystem workspace:

```bash
mkdir -p "$HOME/default_workspace"
cd "$HOME/default_workspace"
opp_env init                 # only for a new workspace
opp_env install simu5g-1.8.0
```

The tested resolved stack is OMNeT++ 6.5.0, INET 4.7.0, Simu5G 1.8.0.
The C++ integration depends on these APIs. A different version needs validation.
The `opp_env` Windows WSL distribution is also supported.

Clone/download this repository, then in its directory:

```bash
bash scripts/setup.sh cpu
# Or, for NVIDIA CUDA (several GB of dependencies):
bash scripts/setup.sh cuda
```

For Windows CUDA, install a compatible NVIDIA **Windows host** driver with WSL support.
Do not replace it with a Linux display driver inside WSL.
Check `nvidia-smi`, then `.venv/bin/python scripts/check_environment.py --device cuda`.
The pinned PyTorch build is 2.8.0 / CUDA 12.6. See the official
[PyTorch installation instructions](https://pytorch.org/get-started/locally/) and
[NVIDIA WSL guide](https://docs.nvidia.com/cuda/wsl-user-guide/index.html).

TiRex-2's Triton path failed on the tested GTX 1650 Ti (compute capability 7.5).
This adapter rejects TiRex CUDA on pre-Ampere GPUs: use TiRex CPU or Chronos CUDA.
TiRex CUDA on Ampere+ is implemented but must be validated on the user's hardware.
GPU memory requirements depend on model and input; 4 GB is not a universal guarantee.
Models download from Hugging Face on first use. Later use `dashboard.py --offline` or
`benchmark.py --offline` to require cached weights.

## Start the live experiment

```bash
NETWORK_AI_MODEL=tirex NETWORK_AI_DEVICE=cpu bash run_live.sh
# Alternative:
NETWORK_AI_MODEL=chronos NETWORK_AI_DEVICE=cuda bash run_live.sh
```

Open http://localhost:8766 and press Run in Qtenv after initialization.
Windows users can run `.\lab.cmd live --model chronos --device cuda`
from PowerShell in the repository directory; the distribution defaults to `opp_env`.
Initial model loading and a separate 129-second calibration simulation happen first.
Its final 128 measurements prepare the model; this is not the same continuous Qtenv run.
The main run lasts 180 simulation seconds. Missing observations remain missing, not zero.
The browser does not need to be closed between runs; restart the launcher and refresh it.

Useful environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `NETWORK_AI_MODEL` | `tirex` | `tirex`, `chronos`, `persistence` |
| `NETWORK_AI_DEVICE` | `cpu` | `cpu`, `cuda`, `auto` |
| `NETWORK_AI_MODEL_REVISION` | `main` | Hugging Face revision; use exported commit hash for repeatability |
| `NETWORK_AI_CAUSE` | `interference` | Automatic schedule: `interference`, `power`, `load` |
| `NETWORK_AI_SEED` | `0` | Main simulation seed |
| `NETWORK_AI_PORT` | `8766` | Local dashboard port |
| `NETWORK_AI_UI` | `Qtenv` | `Qtenv` or headless `Cmdenv` |
| `NETWORK_AI_REALTIME` | `1` | Wall-clock pacing; `0` for explicitly accelerated simulation |
| `NETWORK_AI_WORKSPACE` | `$HOME/default_workspace` | opp_env workspace |
| `NETWORK_AI_PYTHON` | project `.venv/bin/python` | Alternative Python environment |
| `NETWORK_AI_OPP_ENV` | discovered/local opp_env | opp_env executable |

Legacy `$HOME/network-ai/.venv` and `$HOME/network-ai-gpu/.venv` are supported when
there is no project `.venv`. New users should use `scripts/setup.sh`.

The launch scripts ignore inherited Python-specific paths (`-E -s`) so they can also
be started from an active opp_env shell. For direct Python commands inside that shell,
use `.venv/bin/python -E -s benchmark.py ...`. If NumPy mentions Python 3.13 while
your interpreter is 3.12, it is an environment-path collision, not a reason to reinstall NumPy.

Real-time pacing is best effort, not a hard deadline guarantee. Qtenv rendering or CPU/GPU
overload can slow simulation. Telemetry never waits for the AI worker: its pending job is
replaced with the latest context if busy. Skipped forecasts are counted; measurements are retained.

## Cause controls and reading the results

The site controls **one** manual cause at a time:

| Cause | Intensity 0–100% means | Location |
|---|---|---|
| Co-channel interference | External cell occupies 0–100% of RBs | gNB → UE radio link |
| Transmitter power drop | gNB power reduced by 0–40 dB | gNB → UE radio link |
| Offered load | Server send rate multiplied by 1–20 | server → gNB → UE path |

Other manual effects return to baseline when a new cause is applied; automatic scheduling
resumes after expiry. Commands apply on the next simulation-second boundary, so paused
Qtenv must resume first. The event journal records simulator acknowledgement.

Green is measured throughput. Purple is timely historical prediction; grey is late/unknown
availability. Yellow only shows still-future targets from the last completed forecast.
Vertical markers show simulator phase changes. The optional pink line is persistence.

Degradation currently means received throughput <50% of the same second's offered traffic.
This is an experiment threshold, not a standardized radio fault detector. Queues and delayed
delivery can affect it. The journal evaluates the latest available forecast covering the onset.
The warning table additionally counts correct/false warnings and missed degraded target seconds
for each horizon, using only timely results and the offered load known at forecast origin.
These are per-second counts, not incident counts. Learned cause classification/localization is not implemented.
An unexpected abrupt intervention need not be predictable from earlier link measurements.

AI inputs: throughput plus available sent rate, SINR, BLER/HARQ errors and attempts, MAC loss,
CQI, allocated RBs, delay, jitter, modulation bits, code rate, RLC queue, deadline misses,
delivered and pending packet counts. Future intervention schedules are never model inputs.
The persistence baseline intentionally uses only the last throughput.

## Fair model benchmark on your GPU

Download **Stiahnuť celý beh pre benchmark** after a completed live run.
Then run all models on the same historical windows:

```bash
.venv/bin/python benchmark.py run.json --models tirex chronos persistence --device cpu
# GTX 1650 Ti or another pre-Ampere NVIDIA GPU:
.venv/bin/python benchmark.py run.json --models chronos persistence --device cuda
# Compatible Ampere+ GPU:
.venv/bin/python benchmark.py run.json --models tirex chronos persistence --device cuda
```

Use `--max-windows 5` for a smoke test, `--stride 1` for all windows,
or `--target-only` for an ablation without link covariates.
Raw telemetry remains under `runs/`; normal launcher exit also attempts to save `run.json`.
Results under `benchmark-results/` include per-model predictions, per-horizon MAE,
baseline MAE, mean/p95 runtime, GPU peak allocated memory, dependency versions and input SHA-256.
Models run sequentially to avoid shared-GPU contention. Warm-up calls are excluded from latency.
Open the generated `report.html` for a readable Slovak comparison table.
Negative model outputs are retained for honest evaluation.

**Offline latency is not live timeliness.** Live availability uses the latest received simulation
second when inference finishes, with strict `available_at_s < target_time_s`. This has one-second
granularity and is not a hardware-clock latency measurement. For live comparisons use the same
seed/cause without different manual interventions, and keep raw exported runs.

## Tests and contributions

```bash
.venv/bin/python -m unittest discover -p 'test_*.py'
```

Add a model in `model_adapters.py`: accept exactly 128 target values and past-only covariates,
return five finite predictions, synchronize GPU completion, expose metadata. Do not pass
future actuals, future event labels or the intervention schedule to a model.
Use a new recording/seed for evaluation after tuning; one deterministic run is not evidence
of general predictive capability.

## Repository and licensing

Commit source, configuration, tests and documentation. `.gitignore` excludes environments,
model outputs, raw runs, binaries and caches. Dependencies and model weights are installed
separately; they are not vendored. Review their upstream licenses before redistribution or
commercial use, particularly OMNeT++'s academic license and model terms.
This repository has not been uploaded automatically. The project owner must choose a license
for their own code before public distribution and confirm their team/university's permissions.

Official APIs: [TiRex-2](https://github.com/NX-AI/tirex-2),
[Chronos-2](https://github.com/amazon-science/chronos-forecasting),
[Simu5G](https://github.com/Unipisa/Simu5G).
