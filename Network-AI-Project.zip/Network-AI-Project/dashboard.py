"""Local TiRex-2 dashboard with a causal, one-second replay of Simu5G CSV."""

import argparse
import errno
import csv
import io
import json
import math
import os
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
import torch
from forecast_evaluation import evaluate_horizons, evaluate_alerts
from model_adapters import Predictor, MODELS


METRIC_NAMES = ["sent_bps", "sinr_db", "bler_first", "harq_error_rate", "harq_attempts",
    "mac_loss_rate", "cqi", "allocated_rb", "delay_ms", "jitter_ms",
    "modulation_bits", "code_rate", "rlc_queue_bytes", "deadline_missed_packets",
    "delivered_packets", "pending_packets"]

class Replay:
    def __init__(self, path, live=False, scenario="VoIP-DL", warmup=None, prediction_ready=None, model="tirex", device="cpu", offline=False):
        self.model_name, self.device, self.offline = model, device, offline
        self.model_metadata = {}
        self.live = live
        self.scenario = scenario
        self.path = path
        self.warmup = warmup
        self.prediction_ready = prediction_ready
        self.rows = []
        if not live:
            with path.open(newline="", encoding="utf-8-sig") as handle:
                self.rows = [(float(r["sim_time_s"]), float(r["throughput_downlink"]))
                             for r in csv.DictReader(handle)]
            data = np.asarray(self.rows)
            if len(data) < 133 or not np.isfinite(data).all() or np.any(data[:, 1] < 0):
                raise ValueError("CSV requires at least 133 finite nonnegative measurements")
            if not np.allclose(np.diff(data[:, 0]), 1, rtol=0, atol=1e-6):
                raise ValueError("CSV must contain consecutive one-second measurements")
        self.lock = threading.Lock()
        self.count = 0
        self.running = False
        self.ready = False
        self.error = None
        self.generation = 0
        self.forecasts = []
        self.line_metrics = None
        self.measurements = []
        self.prepared_measurements = []
        self.busy = False
        self.prediction_error = None
        self.skipped_predictions = 0
        self.run_id = None
        self.command_id = 0
        self.warning_model = None
        self.warning_records = []
        warning_path = os.environ.get('NETWORK_AI_WARNING_MODEL')
        if warning_path:
            from risk_models import WarningModel
            self.warning_model = WarningModel(warning_path)

    def update_warning(self):
        if self.warning_model is None:
            return
        from risk_protocol import eligible
        with self.lock:
            history = (self.prepared_measurements + self.measurements)[-128:]
            generation = self.generation
        if not eligible(history):
            return
        started = time.perf_counter()
        score = self.warning_model(history)
        with self.lock:
            if generation == self.generation:
                self.warning_records.append(dict(issued_at=history[-1][0],
                    available_at_s=self.count, score=score,
                    alarm=score >= self.warning_model.threshold,
                    latency_ms=(time.perf_counter()-started)*1000))

    def control(self, action):
        if self.live:
            return
        with self.lock:
            if action in ("reset", "prefill"):
                self.generation += 1
                self.count = 127 if action == "prefill" else 0
                self.forecasts = []
                self.running = False
            elif action == "start" and self.ready and not self.error:
                self.running = self.count < len(self.rows)
            elif action == "pause":
                self.running = False

    def set_interference(self, request):
        with self.lock:
            if not self.live or self.scenario != "VariableRadio" or self.run_id is None or self.count >= 180:
                raise ValueError("Ovládanie je dostupné počas behu VariableRadio.")
            if request.get("run_id") != str(self.run_id):
                raise ValueError("Beh simulácie sa zmenil. Obnovte stránku.")
            mode = request.get("mode")
            load = request.get("load")
            duration = request.get("duration")
            cause = request.get("cause", "external_radio_interference")
            causes = ('external_radio_interference', 'transmitter_power_drop', 'offered_load')
            if cause not in causes:
                raise ValueError('Neznáma príčina zhoršenia.')
            if mode not in ("auto", "manual") or type(load) not in (int, float) or not math.isfinite(load) or not 0 <= load <= 1:
                raise ValueError("Neplatný režim alebo intenzita rušenia.")
            if type(duration) is not int or not 1 <= duration <= 180:
                raise ValueError("Trvanie musí byť celé číslo od 1 do 180 s.")
            self.command_id += 1
            path = Path(str(self.path) + ".control")
            temporary = path.with_suffix(".pending")
            temporary.write_text(f"{self.run_id} {self.command_id} {int(mode == 'manual')} {load} {duration} {causes.index(cause)}\n")
            temporary.replace(path)
            return dict(command_id=self.command_id)

    def interference_events(self, run_id, now, forecasts, measurements):
        path = Path(str(self.path) + ".events.csv")
        phases = []
        if path.exists():
            with path.open() as handle:
                for line in handle:
                    if not line.endswith("\n"):
                        continue
                    fields = line.strip().split(",")
                    if len(fields) not in (5, 7) or fields[0] != str(run_id):
                        continue
                    _, second, phase, load, command = fields[:5]
                    cause = fields[5] if len(fields) == 7 else 'external_radio_interference'
                    severity = float(fields[6]) if len(fields) == 7 else float(load)
                    location = 'server → gnb → ue[0]' if cause == 'offered_load' else 'gnb → ue[0]'
                    second, load, command = int(second), float(load), int(command)
                    if second > now:
                        continue
                    if phases and phases[-1]["phase"] == phase and phases[-1]["command_id"] == command and phases[-1]['cause'] == cause:
                        phases[-1]["load_last"] = load
                        phases[-1]['severity'] = severity
                        continue
                    if phases:
                        phases[-1]["end_s"] = second
                    phases.append(dict(start_s=second, end_s=None, phase=phase,
                        load_start=load, load_last=load, command_id=command,
                        location=location, cause=cause, severity=severity))
        episodes = []
        sent_index = METRIC_NAMES.index("sent_bps") + 2
        sent_history = {r[0]: r[sent_index] for r in self.prepared_measurements + measurements}
        for row in measurements:
            second, actual = row[:2]
            sent = row[sent_index]
            degraded = sent is not None and sent > 0 and actual < 0.5 * sent
            if degraded and (not episodes or episodes[-1]["end_s"] is not None):
                candidates = [f for f in forecasts if f.get("available_at_s") is not None and f['available_at_s'] < second
                              and 1 <= second - f["issued_at"] <= 5]
                forecast = max(candidates, key=lambda f: f.get("available_at_s", f["issued_at"]), default=None)
                predicted = forecast["values"][second-forecast["issued_at"]-1] if forecast else None
                origin_sent = sent_history.get(forecast['issued_at']) if forecast else None
                warning_threshold = .5 * origin_sent if origin_sent is not None and origin_sent > 0 else None
                source = next((p for p in reversed(phases) if p["start_s"] < second), None)
                episodes.append(dict(start_s=second, end_s=None, actual_bps=actual,
                    threshold_bps=0.5*sent, predicted_bps=predicted,
                    warning_threshold_bps=warning_threshold,
                    warned=predicted is not None and warning_threshold is not None and predicted < warning_threshold,
                    lead_s=second-forecast.get("available_at_s", forecast["issued_at"]) if forecast else None,
                    forecast_origin_s=forecast["issued_at"] if forecast else None,
                    phase=source["phase"] if source else None,
                    cause=source['cause'] if source else 'unknown',
                    location=source['location'] if source else 'unknown'))
            elif not degraded and episodes and episodes[-1]["end_s"] is None:
                episodes[-1]["end_s"] = second
        return phases, episodes

    def snapshot(self):
        with self.lock:
            observed = list(self.rows) if self.live else self.rows[:self.count]
            forecasts = list(self.forecasts)
            measurements = list(self.measurements)
            run_id = self.run_id
            state = dict(count=self.count, total=len(self.rows), running=self.running,
                         warning_records=list(self.warning_records),
                         warning_model=dict(kind=self.warning_model.artifact['kind'], threshold=self.warning_model.threshold) if self.warning_model else None,
                         live=self.live, scenario=self.scenario, line_metrics=self.line_metrics,
                         model_metadata=self.model_metadata,
                         experiment=dict(seed=os.environ.get('NETWORK_AI_SEED', '0'),
                             automatic_cause=os.environ.get('NETWORK_AI_CAUSE', 'interference'),
                             realtime_requested=os.environ.get('NETWORK_AI_REALTIME', '1') == '1',
                             simulator_stack='OMNeT++ 6.5.0 / INET 4.7.0 / Simu5G 1.8.0'),
                         measurements=measurements, prepared_measurements=list(self.prepared_measurements),
                         prepared_history=128 if self.warmup else 0,
                         run_id=str(run_id) if run_id is not None else None,
                         controls_enabled=self.live and self.scenario == "VariableRadio" and run_id is not None and self.count < 180,
                         requested_command_id=self.command_id,
                         ready=self.ready, error=self.error, busy=self.busy,
                         prediction_error=self.prediction_error,
                         skipped_predictions=self.skipped_predictions,
                         prediction_lag_s=self.count-forecasts[-1]["issued_at"] if forecasts else None)
        phases, episodes = self.interference_events(run_id, state["count"], forecasts, measurements)
        state.update(interference_events=phases, degradation_events=episodes)
        state['horizon_scores'] = evaluate_horizons(observed, forecasts)
        state['alert_scores'] = evaluate_alerts(state['prepared_measurements'] + measurements, forecasts)
        state['warning_scores'] = None
        if self.warning_model and len(measurements) >= 10:
            from risk_protocol import onsets, evaluate
            starts = onsets(state['prepared_measurements'] + measurements)
            completed = [dict(r, label=int(any(r['issued_at'] < s <= r['issued_at']+5 for s in starts)))
                         for r in state['warning_records'] if r['issued_at']+6 <= state['count']]
            if completed:
                state['warning_scores'] = evaluate(state, completed)
        actual = dict(observed)
        errors, baseline_errors = [], []
        for forecast in forecasts:
            for step, value in enumerate(forecast["values"], 1):
                target_time = forecast["issued_at"] + step
                if target_time in actual:
                    errors.append(value - actual[target_time])
                    baseline_errors.append(forecast["baseline"] - actual[target_time])
        durations = [f["latency_ms"] for f in forecasts]
        state.update(observed=observed, forecasts=forecasts, scored=len(errors),
                     mae=float(np.mean(np.abs(errors))) if errors else None,
                     baseline_mae=float(np.mean(np.abs(baseline_errors))) if errors else None,
                     rmse=math.sqrt(float(np.mean(np.square(errors)))) if errors else None,
                     p95_ms=float(np.percentile(durations, 95)) if durations else None)
        return state

    def work(self):
        try:
            predictor = Predictor(self.model_name, self.device, self.offline)
            self.model_metadata = predictor.metadata()
            predict = predictor
            for _ in range(3):
                predict([0.0] * 128 if self.live else [value for _, value in self.rows[:128]])
            with self.lock:
                self.ready = True
            if self.live:
                self.follow(predict)
                return
            deadline = time.monotonic()
            while True:
                with self.lock:
                    running = self.running
                if not running:
                    deadline = time.monotonic()
                    time.sleep(0.05)
                    continue
                time.sleep(max(0, deadline - time.monotonic()))
                with self.lock:
                    if not self.running:
                        continue
                    self.count += 1
                    count, generation = self.count, self.generation
                    self.busy = count >= 128
                    context = [value for _, value in self.rows[max(0, count - 128):count]]
                started = time.perf_counter()
                if count >= 128:
                    values = predict(context)
                    latency = (time.perf_counter() - started) * 1000
                    with self.lock:
                        if generation == self.generation:
                            self.forecasts.append(dict(issued_at=self.rows[count - 1][0],
                                                       values=values, baseline=context[-1],
                                                       latency_ms=latency))
                with self.lock:
                    self.busy = False
                    if generation == self.generation and count == len(self.rows):
                        self.running = False
                # Under overload, slow the replay instead of dropping measurements.
                deadline = max(deadline + 1, time.monotonic())
        except Exception as exc:
            if self.prediction_ready:
                self.prediction_ready.with_suffix('.error').write_text(str(exc), encoding='utf-8')
            with self.lock:
                self.error = str(exc)
                self.running = False
                self.busy = False

    def follow(self, predict):
        predictor_uses_features = getattr(predict, "use_covariates", True)
        names = METRIC_NAMES
        histories = {name: deque(maxlen=128) for name in names}
        prepared = []
        condition = threading.Condition(self.lock)
        pending = None

        def parse(line):
            fields = line.rstrip("\n").split(",")
            if len(fields) not in (3, 5, 19):
                raise ValueError("Unexpected telemetry format")
            run, second, bits = map(int, fields[:3])
            if bits < 0:
                raise ValueError("Negative throughput")
            metrics = dict.fromkeys(names)
            for name, field in zip(names, fields[3:]):
                value = float(field) if field else None
                if value is not None and not math.isfinite(value):
                    raise ValueError(f"Invalid {name} at second {second}")
                metrics[name] = value
            return run, second, bits, metrics

        if self.warmup:
            while not self.warmup.with_suffix(".ready").exists():
                time.sleep(0.1)
            prepared = [parse(line) for line in self.warmup.read_text().splitlines()
                        if line.strip()]
            prepared = [row for row in prepared if row[1] > 0][-128:]
            if len(prepared) != 128 or any(
                prepared[i][1] != prepared[i-1][1] + 1 for i in range(1, 128)
            ):
                raise ValueError("Warm-up requires 128 consecutive simulation measurements")

        def reset():
            nonlocal pending
            with condition:
                self.generation += 1
                pending = None
                self.skipped_predictions = 0
                self.run_id = None
                self.rows.clear()
                self.measurements.clear()
                self.forecasts.clear()
                self.warning_records.clear()
                self.count = 0
                self.line_metrics = None
                for history in histories.values():
                    history.clear()
                for index, (_, _, bits, metrics) in enumerate(prepared):
                    self.rows.append((index - 127, bits))
                    for name, history in histories.items():
                        history.append(metrics[name])
                self.prepared_measurements = [[i - 127, bits] + [metrics[n] for n in names]
                                             for i, (_, _, bits, metrics) in enumerate(prepared)]

        def schedule_forecast(second):
            nonlocal pending
            with condition:
                if len(self.rows) < 128 or self.prediction_error:
                    return
                active = [name for name, history in histories.items()
                          if any(value is not None for value in history)]
                features = [[math.nan if value is None else value for value in histories[name]]
                            for name in active]
                context = [value for _, value in self.rows[-128:]]
                if pending is not None:
                    self.skipped_predictions += 1
                pending = (self.generation, second, context, active, features)
                condition.notify()

        def prediction_worker():
            nonlocal pending
            while True:
                with condition:
                    condition.wait_for(lambda: pending is not None)
                    generation, second, context, active, features = pending
                    pending = None
                    self.busy = True
                started = time.perf_counter()
                try:
                    covariates = torch.tensor(features, dtype=torch.float32) if features else None
                    values = predict(context, covariates)
                except Exception as exc:
                    if self.prediction_ready:
                        self.prediction_ready.with_suffix('.error').write_text(str(exc), encoding='utf-8')
                    with condition:
                        self.prediction_error = str(exc)
                        self.busy = False
                        pending = None
                    return
                with condition:
                    if generation == self.generation:
                        self.forecasts.append(dict(issued_at=second, values=values,
                            baseline=context[-1], feature_names=active if predictor_uses_features else [],
                            available_at_s=self.count,
                            latency_ms=(time.perf_counter() - started) * 1000))
                        if second == 0 and self.prediction_ready:
                            self.prediction_ready.touch()
                    self.busy = False

        reset()
        threading.Thread(target=prediction_worker, daemon=True,
                         name="live-prediction").start()
        if prepared:
            self.update_warning()
            schedule_forecast(0)
        run_id = None
        with self.path.open(encoding="ascii") as stream:
            while True:
                offset = stream.tell()
                line = stream.readline()
                if not line.endswith("\n"):
                    stream.seek(offset)
                    time.sleep(0.05)
                    continue
                incoming_run, second, bits, metrics = parse(line)
                if incoming_run != run_id:
                    if run_id is not None:
                        reset()
                        if prepared:
                            self.update_warning()
                            schedule_forecast(0)
                    run_id = incoming_run
                    with self.lock:
                        self.run_id = incoming_run
                    if second == 0 and bits == 0:
                        continue
                with self.lock:
                    if second != self.count + 1:
                        raise ValueError(f"Invalid live measurement at second {second}")
                    self.rows.append((second, bits))
                    for name, history in histories.items():
                        history.append(metrics[name])
                    self.line_metrics = metrics
                    self.measurements.append([second, bits] + [metrics[name] for name in names])
                    self.count += 1
                self.update_warning()
                schedule_forecast(second)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--scenario", default="VoIP-DL")
    parser.add_argument("--ready-file", type=Path)
    parser.add_argument("--warmup", type=Path)
    parser.add_argument("--prediction-ready", type=Path)
    parser.add_argument("--model", choices=MODELS, default=os.environ.get("NETWORK_AI_MODEL", "tirex"))
    parser.add_argument("--device", choices=("cpu", "cuda", "auto"), default=os.environ.get("NETWORK_AI_DEVICE", "cpu"))
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    replay = Replay(args.csv, live=args.live, scenario=args.scenario,
                    warmup=args.warmup, prediction_ready=args.prediction_ready,
                    model=args.model, device=args.device, offline=args.offline)
    page = Path(__file__).with_name("dashboard.html").read_bytes()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def respond(self, content, content_type, status=200):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)

        def do_GET(self):
            if self.path == "/":
                self.respond(page, "text/html; charset=utf-8")
            elif self.path == "/api/state":
                self.respond(json.dumps(replay.snapshot(), allow_nan=False).encode(), "application/json")
            elif self.path == "/events.json":
                state = replay.snapshot()
                self.respond(json.dumps(dict(interference=state["interference_events"],
                    degradation=state["degradation_events"]), allow_nan=False).encode(), "application/json")
            elif self.path == "/run.json":
                self.respond(json.dumps(replay.snapshot(), allow_nan=False).encode(), "application/json")
            elif self.path == "/telemetry.csv":
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(["sim_time_s", "throughput_downlink_bps"] + METRIC_NAMES)
                with replay.lock:
                    writer.writerows(replay.measurements)
                self.respond(output.getvalue().encode(), "text/csv; charset=utf-8")
            elif self.path == "/predictions.csv":
                state = replay.snapshot()
                actual = dict(state["observed"])
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(["issued_at_s", "target_time_s", "horizon", "prediction_bps",
                                 "actual_bps", "baseline_bps", "latency_ms",
                                 "available_at_s", "available_before_target"])
                for forecast in state["forecasts"]:
                    for step, value in enumerate(forecast["values"], 1):
                        target = forecast["issued_at"] + step
                        writer.writerow([forecast["issued_at"], target, step, value,
                                         actual.get(target, ""), forecast["baseline"], forecast["latency_ms"],
                                         forecast.get("available_at_s", forecast["issued_at"]),
                                         forecast.get("available_at_s", forecast["issued_at"]) < target])
                self.respond(output.getvalue().encode(), "text/csv; charset=utf-8")
            else:
                self.respond(b"Not found", "text/plain", 404)

        def do_POST(self):
            # JSON and same-origin checks prevent cross-site form control of replay.
            origin = self.headers.get("Origin")
            if origin and origin != "http://" + self.headers.get("Host", ""):
                self.respond(b"Forbidden", "text/plain", 403)
                return
            if self.path == "/api/interference":
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if self.headers.get("Content-Type") != "application/json" or not 0 < length <= 2048:
                        raise ValueError("Neplatná požiadavka.")
                    request = json.loads(self.rfile.read(length))
                    if not isinstance(request, dict):
                        raise ValueError("Neplatná požiadavka.")
                    result = replay.set_interference(request)
                    self.respond(json.dumps(result).encode(), "application/json")
                except (ValueError, TypeError) as exc:
                    self.respond(json.dumps(dict(error=str(exc))).encode(), "application/json", 400)
                except OSError:
                    self.respond(json.dumps(dict(error="Príkaz sa nepodarilo zapísať. Skúste znova.")).encode(), "application/json", 500)
                return
            action = self.path.removeprefix("/api/")
            if action not in ("start", "pause", "reset", "prefill") or self.headers.get("Content-Type") != "application/json":
                self.respond(b"Invalid action", "text/plain", 400)
                return
            replay.control(action)
            self.respond(b"{}", "application/json")

    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError as exc:
        if exc.errno == errno.EADDRINUSE:
            parser.exit(1, f"Dashboard port {args.port} is already in use. "
                        "Stop the previous dashboard or set NETWORK_AI_PORT to a free port.\n")
        raise
    with server:
        threading.Thread(target=replay.work, daemon=True).start()
        mode = "live Qtenv" if args.live else "CSV replay"
        print(f"Dashboard: http://localhost:{args.port} ({mode}, {args.model}, {args.device})", flush=True)
        if args.ready_file:
            args.ready_file.touch()
        server.serve_forever()


if __name__ == "__main__":
    main()
