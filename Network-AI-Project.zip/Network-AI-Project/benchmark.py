"""Compare models on identical past-only windows from a downloaded /run.json."""
import argparse
import csv
import gc
import hashlib
import html
import json
from pathlib import Path
import time
import numpy as np
import torch
from model_adapters import Predictor, MODELS
from forecast_evaluation import evaluate_horizons


def write_html(report, path):
    rows = []
    for result in report['results']:
        name = html.escape(result['model'])
        if 'error' in result:
            rows.append(f'<tr><td>{name}</td><td colspan="5">{html.escape(result["error"])}</td></tr>')
            continue
        errors = ''.join(f'<td>{score["all_mae"]/1000:.2f}</td>' for score in result['horizons'])
        rows.append(f'<tr><td>{name}</td><td>{html.escape(result["device"])}</td>'
                    f'<td>{result["p95_ms"]:.2f}</td>{errors}</tr>')
    page = '''<!doctype html><html lang="sk"><meta charset="utf-8"><title>Benchmark modelov</title>
<style>body{background:#0c121d;color:#e8edf5;font:16px system-ui;max-width:1100px;margin:40px auto;padding:20px}table{border-collapse:collapse;width:100%}th,td{padding:14px;border-bottom:1px solid #354962;text-align:left}p{line-height:1.6;color:#a6b5c9}code{overflow-wrap:anywhere}</style>
<h1>Porovnanie modelov na rovnakých meraniach</h1>
<p>Nižšie MAE je lepšie. Persistence = posledná známa rýchlosť, nie AI.
Offline benchmark nehodnotí včasnosť živých predikcií. Načítanie a zahrievanie modelov nie sú v latencii.</p>
<table><tr><th>Model</th><th>Zariadenie</th><th>p95, ms</th><th>MAE +1 s, kbit/s</th><th>MAE +3 s</th><th>MAE +5 s</th></tr>'''
    page += ''.join(rows) + f'</table><p>Rovnakých okien: {report["windows"]}. SHA-256 vstupu: <code>{report["input_sha256"]}</code></p>'
    page += '<p>Podrobnosti, verzie a pamäť GPU: <a href="report.json">report.json</a>. Predikcie sú v CSV vedľa tejto stránky.</p></html>'
    path.write_text(page, encoding='utf-8')


def windows(state, stride=1):
    rows = state.get('prepared_measurements', []) + state.get('measurements', [])
    if len(rows) < 133:
        raise ValueError('Export a complete run.json with at least 133 measurements (including preparation).')
    if any(b[0] - a[0] != 1 for a, b in zip(rows, rows[1:])):
        raise ValueError('Measurements must be consecutive and belong to a single run')
    for end in range(128, len(rows) - 4, stride):
        history = rows[end-128:end]
        if history[-1][0] < 0:
            continue
        context = [r[1] for r in history]
        features = np.asarray([[np.nan if r[i] is None else r[i] for r in history]
                              for i in range(2, len(history[0]))], dtype=np.float32)
        if features.size:
            features = features[~np.isnan(features).all(axis=1)]
        yield history[-1][0], context, features if features.size else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    parser.add_argument('--models', nargs='+', choices=MODELS, default=list(MODELS))
    parser.add_argument('--device', choices=['cpu', 'cuda', 'auto'], default='cpu')
    parser.add_argument('--offline', action='store_true')
    parser.add_argument('--target-only', action='store_true')
    parser.add_argument('--stride', type=int, default=1)
    parser.add_argument('--max-windows', type=int)
    parser.add_argument('--output', type=Path, default=Path('benchmark-results'))
    args = parser.parse_args()
    if args.stride < 1 or (args.max_windows is not None and args.max_windows < 1):
        parser.error('stride and max-windows must be positive')
    raw = args.run.read_bytes()
    state = json.loads(raw.decode('utf-8-sig'))
    tasks = list(windows(state, args.stride))
    if args.max_windows:
        tasks = tasks[:args.max_windows]
    if not tasks:
        parser.error('No complete forecast windows')
    output = args.output / time.strftime('%Y%m%d-%H%M%S')
    output.mkdir(parents=True, exist_ok=False)
    report = dict(input_sha256=hashlib.sha256(raw).hexdigest(), run_id=state.get('run_id'),
                  experiment=state.get('experiment'),
                  scenario=state.get('scenario'), protocol='offline-identical-windows',
                  note='Offline latency is measured; live availability is NOT inferred from offline timings.',
                  stride=args.stride, windows=len(tasks), results=[])
    actual = dict(state['observed'])
    failed = False
    for name in args.models:
        predictor = None
        try:
            torch.manual_seed(0)
            predictor = Predictor(name, args.device, args.offline, not args.target_only)
            for _ in range(2):
                predictor(tasks[0][1], tasks[0][2])
            if predictor.device == 'cuda':
                torch.cuda.reset_peak_memory_stats()
            forecasts = []
            for issued, context, features in tasks:
                start = time.perf_counter()
                values = predictor(context, features)
                forecasts.append(dict(issued_at=issued, values=values, baseline=context[-1],
                                      latency_ms=(time.perf_counter()-start)*1000))
            latency = [f['latency_ms'] for f in forecasts]
            scores = evaluate_horizons(state['observed'], forecasts)
            result = dict(**predictor.metadata(), horizons=scores,
                          mean_ms=float(np.mean(latency)), p95_ms=float(np.percentile(latency, 95)),
                          peak_gpu_allocated_mb=torch.cuda.max_memory_allocated()/2**20
                          if predictor.device == 'cuda' else None)
            with (output / f'{name}-predictions.csv').open('w', newline='') as handle:
                writer = csv.writer(handle)
                writer.writerow(['issued_at_s','target_time_s','horizon','prediction_bps','actual_bps','baseline_bps','latency_ms'])
                for f in forecasts:
                    for h, value in enumerate(f['values'], 1):
                        writer.writerow([f['issued_at'],f['issued_at']+h,h,value,actual[f['issued_at']+h],f['baseline'],f['latency_ms']])
            print(name, 'p95 ms:', round(result['p95_ms'], 2), flush=True)
        except Exception as exc:
            failed = True
            result = dict(model=name, error=str(exc))
            print(name, 'FAILED:', exc, flush=True)
        finally:
            del predictor
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        report['results'].append(result)
        (output / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
        write_html(report, output / 'report.html')
    print('Report:', output / 'report.json')
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
