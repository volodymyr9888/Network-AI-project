"""Evaluate TiRex-2 on one-second Simu5G measurements (all rates in bit/s)."""

import argparse
import csv
import json
import math
import os
import time
from pathlib import Path

import numpy as np
import torch
from tirex2 import TimeseriesType, load_model


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--windows", type=int, default=1)
    parser.add_argument("--output", type=Path, default=Path("tirex-results"))
    parser.add_argument("--short-context", action="store_true",
                        help="Disable full-context padding for a separately evaluated faster mode")
    args = parser.parse_args()
    with args.csv.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    times = np.array([float(row["sim_time_s"]) for row in rows])
    values = np.array([float(row["throughput_downlink"]) for row in rows], dtype=np.float32)
    if len(values) < 133 or args.windows < 1:
        raise ValueError("Need at least 133 measurements and --windows >= 1")
    if not np.isfinite(values).all() or np.any(values < 0):
        raise ValueError("Throughput must be finite and nonnegative")
    if not np.isfinite(times).all() or not np.allclose(np.diff(times), 1, rtol=0, atol=1e-6):
        raise ValueError("Measurements must be consecutive, one second apart")

    torch.set_num_threads(min(4, os.cpu_count() or 1))
    print("Loading NX-AI/TiRex-2 on CPU...", flush=True)
    model = load_model("NX-AI/TiRex-2", device="cpu")
    quantiles = np.asarray(model.quantiles, dtype=float)
    median_index = int(np.argmin(abs(quantiles - 0.5)))
    if not np.isclose(quantiles[median_index], 0.5):
        raise ValueError("Model does not expose a median quantile")

    def forecast(context):
        series = TimeseriesType(target=torch.from_numpy(context.copy()).unsqueeze(0),
                                past_covariates=None, future_covariates=None)
        with torch.inference_mode():
            result = model.forecast([series], prediction_length=5,
                                    pad_context=not args.short_context, output_type="numpy")[0]
        result = np.asarray(result)
        if result.shape != (1, len(quantiles), 5) or not np.isfinite(result).all():
            raise ValueError(f"Invalid model output: {result.shape}")
        return result[0, median_index]

    print("Warming up on the first 128 measurements...", flush=True)
    for _ in range(3):
        forecast(values[:128])
    output_rows, durations, errors, baseline_errors = [], [], [], []
    count = min(args.windows, len(values) - 132)
    for end in range(128, 128 + count):
        started = time.perf_counter()
        predictions = forecast(values[end - 128:end])
        duration = time.perf_counter() - started
        durations.append(duration)
        for step, prediction in enumerate(predictions):
            actual = float(values[end + step])
            baseline = float(values[end - 1])
            errors.append(float(prediction) - actual)
            baseline_errors.append(baseline - actual)
            output_rows.append([times[end - 1], times[end + step], step + 1,
                                actual, float(prediction), baseline, duration * 1000])
        print(f"Window {end - 127}/{count}: {duration:.3f} s", flush=True)
    metrics = {
        "model": "NX-AI/TiRex-2", "device": "cpu", "unit": "bit/s",
        "context": 128, "horizon": 5, "windows": count,
        "pad_context": not args.short_context,
        "mae": float(np.mean(np.abs(errors))),
        "rmse": math.sqrt(float(np.mean(np.square(errors)))),
        "baseline_mae": float(np.mean(np.abs(baseline_errors))),
        "baseline_rmse": math.sqrt(float(np.mean(np.square(baseline_errors)))),
        "latency_median_ms": float(np.median(durations) * 1000),
        "latency_p95_ms": float(np.percentile(durations, 95) * 1000),
    }
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "predictions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["issued_at_s", "target_time_s", "horizon", "actual_bps",
                         "prediction_bps", "baseline_bps", "latency_ms"])
        writer.writerows(output_rows)
    (args.output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2), flush=True)
    print("First forecast (time, actual, prediction):", flush=True)
    for row in output_rows[:5]:
        print(f"{row[1]:.0f}: {row[3]:.2f} -> {row[4]:.2f}", flush=True)


if __name__ == "__main__":
    main()
