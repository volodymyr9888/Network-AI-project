"""Run real Simu5G experiments. Python schedules interventions; it never synthesizes telemetry."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import random
import subprocess
from lab_data import dump, fingerprint, read_telemetry, validate_state

ROOT = Path(__file__).resolve().parent


def intervention_plan(seed, cause):
    rng = random.Random(seed + 19473)
    baseline = .03 if cause == 0 else 0.0
    plan = {1: (cause, baseline)}
    # Distinct timings per seed; gradual and abrupt cases both retained.
    starts = [rng.randint(16, 26), rng.randint(72, 83), rng.randint(130, 140)]
    for index, start in enumerate(starts):
        ramp = rng.randint(9, 18) if (seed + index) % 2 == 0 else 0
        strength = rng.uniform(.75, 1.0)
        hold = rng.randint(8, 13)
        for step in range(ramp + 1):
            plan[start + step] = (cause, baseline + (strength-baseline)*step/ramp if ramp else strength)
        plan[start + ramp + hold] = (cause, baseline)
    return sorted((t, *value) for t, value in plan.items())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--runs', type=int, default=12)
    parser.add_argument('--workers', type=int, default=2)
    parser.add_argument('--seed-start', type=int, default=200)
    args = parser.parse_args()
    if args.runs < 6 or args.workers not in (1, 2):
        parser.error('Use at least 6 runs and 1 or 2 simulation workers')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    roots = {name: Path(os.environ[name]) for name in ('OMNETPP_ROOT', 'INET_ROOT', 'SIMU5G_ROOT')}
    library = out / 'libdownlink_probe.so'
    subprocess.run([os.environ.get('CXX','clang++'), '-std=c++17','-O2','-DNDEBUG','-DINET_IMPORT','-shared','-fPIC',
        '-I'+str(roots['OMNETPP_ROOT']/'include'), '-I'+str(roots['INET_ROOT']/'src'),
        '-I'+str(roots['SIMU5G_ROOT']/'src'), str(ROOT/'live/DownlinkProbe.cc'), '-o',str(library)], check=True)
    sim = roots['SIMU5G_ROOT']
    ned = ':'.join(map(str,[sim/'simulations',sim/'emulation',sim/'src',roots['INET_ROOT']/'src',ROOT/'live']))
    common = ['opp_run','-l',str(sim/'src/simu5g'),'-u','Cmdenv','--cmdenv-express-mode=true',
              '--network=LiveStandalone','-n',ned,'-l',str(library),'-f','omnetpp.ini','-f',str(ROOT/'live/mobile-downlink.ini')]
    def simulate(folder, seed, config, seconds, plan=None):
        folder.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env.pop('NETWORK_AI_PLAN', None)
        env['NETWORK_AI_CAUSE'] = 'interference'
        env['NETWORK_AI_STREAM'] = str(folder/'telemetry.csv')
        if plan:
            env['NETWORK_AI_PLAN'] = str(plan)
        with (folder/'simulator.log').open('w') as log:
            subprocess.run(common+['-c',config,f'--sim-time-limit={seconds}s',f'--seed-set={seed}',
                '--result-dir='+str(folder/'results')], cwd=sim/'simulations/nr/standalone',
                env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=600)
        return read_telemetry(folder/'telemetry.csv')
    _, warmup = simulate(out/'preparation', 1001, 'RadioWarmup', 129)
    prepared = [[i-127]+row[1:] for i,row in enumerate(warmup[-128:])]
    if len(prepared) != 128:
        raise ValueError('Incomplete calibration run')
    n_train = args.runs // 2
    n_validation = max(1, (args.runs-n_train)//2)
    def collect(i):
        seed, cause = args.seed_start + i, i % 3
        split = 'train' if i < n_train else 'validation' if i < n_train+n_validation else 'test'
        folder = out/f'seed-{seed}'
        folder.mkdir()
        plan = intervention_plan(seed, cause)
        plan_path = folder/'interventions.txt'
        plan_path.write_text(''.join(f'{t} {c} {v:.8f}\n' for t,c,v in plan))
        run_id, measured = simulate(folder, seed, 'VariableRadio', 180, plan_path)
        if len(measured) != 180:
            raise ValueError('Simulation did not produce 180 samples')
        state = dict(run_id=run_id, scenario='VariableRadio', count=180,
            prepared_measurements=prepared, measurements=measured,
            observed=[r[:2] for r in prepared+measured], forecasts=[], model_metadata={},
            experiment=dict(seed=seed,cause=('interference','power','load')[cause],
                source='Simu5G', accelerated_collection=True, intervention_plan=plan))
        validate_state(state)
        dump(folder/'run.json',state)
        entry = dict(path=f'{folder.name}/run.json',seed=seed,split=split,sha256=fingerprint(state))
        print(f'Collected {split}: seed {seed}, {state["experiment"]["cause"]}',flush=True)
        return entry
    manifest = dict(version=1,source='Simu5G',runs=[],
        note='Whole runs split before training. Common separate calibration history. Never use intervention_plan as model features.')
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for entry in pool.map(collect,range(args.runs)):
            manifest['runs'].append(entry)
            dump(out/'manifest.partial.json',manifest)
    dump(out/'manifest.json',manifest)
    print('Dataset:',out/'manifest.json',flush=True)


if __name__ == '__main__':
    main()
