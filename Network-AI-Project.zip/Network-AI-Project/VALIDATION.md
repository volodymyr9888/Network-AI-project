# Local validation — 2026-11-22

Tested on Windows/WSL2, NVIDIA GTX 1650 Ti 4 GB, Python 3.12.16,
PyTorch 2.8.0+cu126, TiRex-2 0.5.0 and chronos-forecasting 2.3.2.
Simulator: OMNeT++ 6.5.0, INET 4.7.0, Simu5G 1.8.0, release build.

- Complete 180-second real-time Cmdenv run with Chronos-2 CUDA: 180 measurements,
  181 forecasts (including the initial prepared prediction), no replaced pending forecasts.
- p95 inference duration approximately 102 ms. All scored +1/+3/+5 forecasts were
  available before target reception at the telemetry's one-second timestamp resolution.
  This does not prove hard wall-clock deadlines on other hardware or under Qtenv animation load.
- Commands acknowledged: power drop at t=6–16; offered load at t=23–33;
  co-channel interference at t=41–51. Automatic scenario resumed after each expiry.
- At t=5: received 4.45 Mbit/s, SINR 35.7 dB. During the 40 dB power drop at t=10:
  received 0, SINR −2.8 dB. At t=20 reception recovered to 4.29 Mbit/s.
- At t=27 offered traffic rose to 50.74 Mbit/s, received traffic was 3.83 Mbit/s,
  RLC queue approximately 7.57 MB. Effects were produced by the packet simulation,
  not injected into the output throughput series.
- Chronos live MAE was worse than persistence by about 14.6%, 6.4%, 9.9% for +1/+3/+5.
  This mixed-intervention run is validation evidence, not a general model ranking.
- Identical-window benchmark smoke test (stride 20, nine windows) passed for TiRex CPU,
  Chronos CPU, Chronos CUDA and persistence. Observed p95: TiRex CPU ~1890 ms,
  Chronos CPU ~386 ms, Chronos CUDA ~105 ms. Small-sample timings are hardware-specific.
- Standard TiRex CUDA inference failed on this pre-Ampere GPU. The adapter now rejects
  that combination explicitly. Ampere+ TiRex CUDA has not been hardware-tested here.
- Unit checks cover strict availability, matching baseline targets, missing measurements,
  zero baseline error, history-only windows, command/run validation, event attribution,
  and prevention of using future offered load to fabricate an advance warning.
- Browser verified: Slovak controls, GPU/model launch command, cause journal,
  metric tables and selectable horizon.

Raw runs and local benchmark outputs are excluded from the source archive. To reproduce,
launch a dedicated test server and use `scripts/smoke_live.py --port PORT --output run.json`.
This script changes the simulation; use it only on a dedicated test run. Actual command
application times may differ by a tick; use the recorded acknowledgement times.


## Early-warning laboratory validation — 2026-11-23

12 complete real Simu5G runs: 6 train, 3 validation, 3 held-out test. Training: 645 eligible windows (90 positive); validation: 329; test: 383 windows and 9 eligible incident onsets. No future intervention schedule enters any model.

| Model | Detected onsets | False episodes | False seconds | Warning precision | p95 ms |
|---|---:|---:|---:|---:|---:|
| logistic | 9/9 | 28 | 168 | 18.8% | 2.4 |
| forest | 9/9 | 19 | 238 | 15.9% | 2.8 |
| trend | 4/9 | 6 | 14 | 36.4% | 0.1 |
| persistence | 0/9 | 0 | 0 | — | 0.3 |
| chronos:cuda | 4/9 | 2 | 13 | 35.0% | 100.1 |
| tirex:cpu | 0/9 | 2 | 2 | 0.0% | 2222.7 |
| always | 9/9 | 12 | 338 | 11.7% | 0.0 |

High recall alone is not success: the always-warning baseline also catches every onset. The learned demo models still generate many false alarms. This is a working comparison laboratory, not validated reliable fault prediction. See [reference report](examples/reference/report.html) for per-run warning timelines and the latency-adjusted estimate.

- AMD Ryzen 5 4600H CPU; Chronos CUDA on GTX 1650 Ti. Ordinary desktop workloads remained active.
- 13 unit tests passed, including no-future-data features, incident confirmation, deadlines, duplicate-run rejection, portable classifier round-trip and float32/double tree thresholds.
- Portable model predictions matched scikit-learn on all training examples before export.
- Replay integration consumed 180 real recorded measurements and evaluated 135 eligible warning decisions, exporting scored incidents. This check is not a live wall-clock benchmark.
- Windows lab.cmd launch, dependency compatibility and JavaScript syntax passed.
- Fresh ZIP extraction passed the documented launcher, training and five-model comparison workflow using the installed Python environment. A completely new machine installation has not been tested.
- The launcher GPU diagnostic confirmed CUDA availability on the GTX 1650 Ti.
- Browser visual verification was not completed: Computer Use stopped because it could not determine the current browser URL.
- Public ZIP includes only source/docs and generated demo/reference outputs; environments, weights and private run folders are excluded.
