# Public simulator demo

`demo/manifest.json` contains 12 complete Simu5G runs: 6 training, 3 validation, 3 test.
Seeds are 200–211. Each run contains 180 one-second measurements plus a shared, separate
128-sample healthy calibration history (seed 1001). One stationary UE, one serving gNB.
The source is OMNeT++ 6.5.0 / INET 4.7.0 / Simu5G 1.8.0 with this repository's probe.

Each split contains external co-channel interference, transmitter power reduction and offered-load changes.
The schedules include both gradual and abrupt changes. Their parameters are reproducible using
`collect_simulations.intervention_plan`. The `experiment.intervention_plan` field is ground truth
for auditing only; it is never used by the model feature extraction.

These are measured outputs of a packet-level simulation, not sampled or fabricated throughput curves,
not NordicDataset and not measurements from a physical mobile network.
Raw `.vec` files and simulator binaries are excluded to keep the example small.

Row columns:

| Index | Measurement | Unit / meaning |
|---|---|---|
| 0 | simulation second | s; calibration −127…0, main run 1…180 |
| 1 | received downlink | bit/s |
| 2 | sent traffic | bit/s |
| 3 | SINR | dB |
| 4 | first-transmission BLER | fraction |
| 5 | HARQ error rate | fraction |
| 6 | HARQ attempts | mean of emitted signal samples |
| 7 | MAC loss rate | fraction |
| 8 | CQI | index |
| 9 | allocated resource blocks | mean of emitted signal samples |
| 10–11 | delay, jitter | ms |
| 12 | modulation | bits/symbol |
| 13 | code rate | ratio |
| 14 | RLC queue | bytes at interval end |
| 15 | missed packet deadlines | count in interval |
| 16 | delivered packets | count in interval |
| 17 | pending packets | tracked packets still within the probe's 1 s deadline |

`null` means unavailable, never a zero measurement. Exact signal subscriptions and aggregation
are defined in `live/DownlinkProbe.cc`.
Deadline misses include packets not delivered within one second; this is not proof of permanent packet loss.
The supplied test split is a demonstration, not a sufficiently large scientific evaluation.
After exploring it, generate new independent runs before making a final model-selection claim.
