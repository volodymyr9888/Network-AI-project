@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\lab_windows.ps1" %*
exit /b %errorlevel%
