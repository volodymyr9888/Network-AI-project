import simu5g.simulations.nr.networks.SingleCell_Standalone;
import simu5g.nodes.ExtCell;
import simu5g.stack.phy.PhyEnb;
import inet.applications.udpapp.UdpBasicApp;

simple ControlledUdpApp extends UdpBasicApp
{
    parameters:
        @class("inet::UdpBasicApp");
        sendInterval @mutable = default(2ms);
}

simple ControlledPhy extends PhyEnb
{
    parameters:
        @class(ControlledPhy);
}

simple DownlinkProbe
{
    parameters:
        @display("i=block/sink;p=800,410");
}

network LiveStandalone extends SingleCell_Standalone
{
    parameters:
        bool radioInterference = default(false);
        bool variableInterference = default(false);
    submodules:
        interferer: ExtCell if radioInterference;
        downlinkProbe: DownlinkProbe;
}
