#pragma once
#include <cmath>
#include "simu5g/stack/phy/PhyEnb.h"

// Adjust the actual transmit power used by Simu5G, including feedback queries.
// This represents transmitter power reduction, not a geometric obstacle model.
class ControlledPhy : public simu5g::PhyEnb {
    double nominalPower = NAN;
  public:
    void setPowerReduction(double lossDb) {
        if (!std::isfinite(nominalPower)) nominalPower = txPower_;
        txPower_ = nominalPower - lossDb;
        eNodeBtxPower_ = txPower_;
    }
};
