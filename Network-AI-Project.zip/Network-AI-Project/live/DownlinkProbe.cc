#include <omnetpp.h>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <map>
#include <vector>
#include "inet/common/packet/Packet.h"
#include "inet/applications/base/ApplicationPacket_m.h"
#include "inet/common/TimeTag_m.h"
#include "simu5g/stack/rlc/um/RlcUmTxEntityBase.h"
#include "simu5g/stack/mac/LteMacEnb.h"
#include "simu5g/stack/mac/amc/NrAmc.h"
#include "simu5g/stack/mac/amc/UserTxParams.h"
#include "simu5g/common/LteControlInfo.h"
#include "simu5g/nodes/ExtCell.h"
#include "ControlledPhy.h"

using namespace omnetpp;
Define_Module(ControlledPhy);

class DownlinkProbe : public cSimpleModule, public cListener
{
    struct Average {
        double sum = 0;
        int count = 0;
        void add(double value) { if (std::isfinite(value)) { sum += value; ++count; } }
    };
    cMessage *tick = nullptr;
    cModule *udp = nullptr, *serverUdp = nullptr, *gnb = nullptr;
    std::vector<std::pair<cComponent *, simsignal_t>> subscriptions;
    std::map<simsignal_t, std::string> numericSignals;
    std::map<std::string, Average> averages;
    std::map<std::string, simtime_t> pending;
    std::ofstream output;
    std::ofstream eventOutput;
    std::string controlPath;
    long long lastCommand = 0;
    double manualLoad = 0;
    int manualCause = 0;
    int automaticCause = 0;
    std::map<int, std::pair<int, double>> experimentPlan;
    int manualUntil = 0;
    long long run = 0, bits = 0, sentBits = 0;
    int second = 0, delivered = 0, lateBeforeTick = 0;
    double previousDelay = NAN;
    simsignal_t received, sent, lower;
    const std::vector<std::string> names = {
        "sinr_db", "bler_first", "harq_error_rate", "harq_attempts",
        "mac_loss_rate", "cqi", "allocated_rb", "delay_ms", "jitter_ms",
        "modulation_bits", "code_rate"
    };

    void listen(cComponent *component, simsignal_t signal) {
        component->subscribe(signal, this);
        subscriptions.emplace_back(component, signal);
    }
    void metric(cComponent *component, const char *signal, const char *name) {
        auto id = registerSignal(signal);
        numericSignals[id] = name;
        listen(component, id);
    }
    double queueBytes(cModule *module) {
        double total = 0;
        if (auto entity = dynamic_cast<simu5g::RlcUmTxEntityBase *>(module))
            total += entity->getBufferOccupancy();
        for (cModule::SubmoduleIterator it(module); !it.end(); ++it)
            total += queueBytes(*it);
        return total;
    }
    void initialize() override {
        auto network = getParentModule();
        const char *cause = std::getenv("NETWORK_AI_CAUSE");
        std::string causeName = cause ? cause : "interference";
        if (causeName == "power") automaticCause = 1;
        else if (causeName == "load") automaticCause = 2;
        else if (causeName != "interference") throw cRuntimeError("NETWORK_AI_CAUSE must be interference, power or load");
        if (const char *planPath = std::getenv("NETWORK_AI_PLAN")) {
            std::ifstream plan(planPath);
            if (!plan) throw cRuntimeError("Cannot open experiment plan");
            int at, type; double strength;
            while (plan >> at >> type >> strength) {
                if (at < 1 || at > 179 || type < 0 || type > 2 || !std::isfinite(strength) || strength < 0 || strength > 1 || experimentPlan.count(at))
                    throw cRuntimeError("Invalid experiment intervention");
                experimentPlan[at] = {type, strength};
            }
            if (!plan.eof()) throw cRuntimeError("Malformed experiment plan");
        }
        if (getEnvir()->isGUI())
            network->getCanvas()->setAnimationSpeed(1.0, this);
        auto ue = network->getSubmodule("ue", 0);
        gnb = network->getSubmodule("gnb");
        auto server = network->getSubmodule("server");
        udp = ue->getSubmodule("udp");
        serverUdp = server->getSubmodule("udp");
        received = registerSignal("packetReceived");
        sent = registerSignal("packetSent");
        lower = registerSignal("sentPacketToLowerLayer");
        listen(udp, received);
        listen(serverUdp, sent);
        listen(ue->getSubmodule("app", 0), received);
        for (int i = 0; i < server->par("numApps").intValue(); ++i)
            listen(server->getSubmodule("app", i), sent);
        listen(gnb->getSubmodule("cellularNic")->getSubmodule("mac"), lower);
        metric(ue, "rcvdSinrDl", "sinr_db");
        metric(ue, "harqErrorRate_1st_Dl", "bler_first");
        metric(ue, "harqErrorRateDl", "harq_error_rate");
        metric(ue, "harqTxAttemptsDl", "harq_attempts");
        metric(ue, "macPacketLossDl", "mac_loss_rate");
        metric(ue, "averageCqiDl", "cqi");
        metric(gnb, "avgServedBlocksDl", "allocated_rb");
        const char *path = std::getenv("NETWORK_AI_STREAM");
        if (!path) throw cRuntimeError("NETWORK_AI_STREAM is required");
        output.open(path, std::ios::app);
        if (!output) throw cRuntimeError("Cannot open telemetry");
        run = std::chrono::system_clock::now().time_since_epoch().count();
        controlPath = std::string(path) + ".control";
        eventOutput.open(std::string(path) + ".events.csv", std::ios::app);
        if (!eventOutput) throw cRuntimeError("Cannot open interference event log");
        if (network->par("radioInterference").boolValue())
            eventOutput << run << ",0,baseline," << network->getSubmodule("interferer")->par("bandUtilization").doubleValue() << ",0" << std::endl;
        output << run << ",0,0" << std::endl;
        tick = new cMessage("downlink measurement");
        tick->setSchedulingPriority(-32768);
        scheduleAt(1, tick);
    }
    void receiveSignal(cComponent *source, simsignal_t signal, cObject *value, cObject *) override {
        auto packet = dynamic_cast<inet::Packet *>(value);
        if (!packet) return;
        if (source == udp) { bits += 8 * packet->getByteLength(); return; }
        if (source == serverUdp) { sentBits += 8 * packet->getByteLength(); return; }
        if (signal == lower) {
            auto info = packet->findTag<simu5g::UserControlInfo>();
            if (!info || info->getDirection() != simu5g::DL || !info->getUserTxParams()) return;
            auto mac = check_and_cast<simu5g::LteMacEnb *>(source);
            auto amc = dynamic_cast<simu5g::NrAmc *>(mac->getAmc());
            if (!amc) return;
            for (auto cqi : info->getUserTxParams()->readCqiVector()) {
                auto mcs = amc->getMcsElemPerCqi(cqi, simu5g::DL);
                averages["modulation_bits"].add(2 * ((int)mcs.mod_ + 1));
                averages["code_rate"].add(mcs.coderate_ / 1024.0);
            }
            return;
        }
        // Payload creation time survives transport and permits measuring late arrivals.
        auto payload = dynamic_cast<const inet::ApplicationPacket *>(packet->peekAtFront().get());
        auto creation = payload ? payload->findTag<inet::CreationTimeTag>() : nullptr;
        std::string key = packet->getName();
        if (creation) key += "@" + creation->getCreationTime().str();
        if (signal == sent) pending[key] = simTime();
        else {
            auto found = pending.find(key);
            if (found == pending.end() && !creation) return;
            simtime_t sentAt = creation ? creation->getCreationTime() : found->second;
            double delay = (simTime() - sentAt).dbl() * 1000;
            averages["delay_ms"].add(delay);
            if (std::isfinite(previousDelay))
                averages["jitter_ms"].add(std::abs(delay - previousDelay));
            previousDelay = delay;
            if (found != pending.end()) {
                if (simTime() - sentAt >= 1) ++lateBeforeTick;
                pending.erase(found);
            }
            ++delivered;
        }
    }
    void receiveSignal(cComponent *, simsignal_t signal, double value, cObject *) override {
        auto found = numericSignals.find(signal);
        if (found != numericSignals.end()) averages[found->second].add(value);
    }
    void receiveSignal(cComponent *source, simsignal_t signal, intval_t value, cObject *details) override {
        receiveSignal(source, signal, (double)value, details);
    }
    void receiveSignal(cComponent *source, simsignal_t signal, uintval_t value, cObject *details) override {
        receiveSignal(source, signal, (double)value, details);
    }
    void receiveSignal(cComponent *source, simsignal_t signal, bool value, cObject *details) override {
        receiveSignal(source, signal, (double)value, details);
    }
    void handleMessage(cMessage *) override {
        int expired = lateBeforeTick;
        lateBeforeTick = 0;
        for (auto it = pending.begin(); it != pending.end();) {
            if (simTime() - it->second >= 1) { ++expired; it = pending.erase(it); }
            else ++it;
        }
        output << run << ',' << ++second << ',' << bits << ',' << sentBits;
        for (const auto& name : names) {
            auto &value = averages[name];
            output << ',';
            if (value.count) output << value.sum / value.count;
        }
        output << ',' << queueBytes(gnb) << ',' << expired << ',' << delivered
               << ',' << pending.size() << std::endl;
        if (!output) throw cRuntimeError("Cannot write telemetry");
        bits = sentBits = 0;
        delivered = 0;
        averages.clear();
        if (getParentModule()->par("variableInterference").boolValue()) {
            // Controlled radio-resource occupation; no future schedule is sent to AI.
            double load = 0.05;
            std::string phase = "baseline";
            if (second >= 20 && second < 60) {
                load = 0.05 + 0.9 * (second - 20) / 40.0;
                phase = "ramp_up";
            }
            else if (second >= 60 && second < 85) {
                load = 0.95;
                phase = "high";
            }
            else if (second >= 85 && second < 120) {
                load = 0.95 - 0.9 * (second - 85) / 35.0;
                phase = "recovery";
            }
            else if ((second >= 135 && second < 143) || (second >= 155 && second < 163)) {
                load = 0.99;
                phase = "burst";
            }
            std::ifstream command(controlPath);
            long long commandRun, commandId;
            int mode, duration, cause = 0;
            double requestedLoad;
            if (command >> commandRun >> commandId >> mode >> requestedLoad >> duration) {
                command >> cause;
                if (commandRun == run && commandId > lastCommand &&
                    (mode == 0 || mode == 1) && std::isfinite(requestedLoad) &&
                    requestedLoad >= 0 && requestedLoad <= 1 && duration >= 1 && duration <= 180 && cause >= 0 && cause <= 2) {
                    lastCommand = commandId;
                    manualLoad = requestedLoad;
                    manualCause = cause;
                    manualUntil = mode == 1 ? second + duration : 0;
                }
            }
            double powerReduction = 0, interval = 0.002, severity = load;
            std::string causeName = "external_radio_interference";
            int activeCause = automaticCause;
            auto planned = experimentPlan.upper_bound(second);
            if (planned != experimentPlan.begin()) {
                --planned;
                activeCause = planned->second.first;
                severity = planned->second.second;
                phase = "experiment";
            }
            if (second < manualUntil) {
                severity = manualLoad;
                activeCause = manualCause;
                phase = "manual";
            }
            load = activeCause == 0 ? severity : 0.05;
                if (activeCause == 1) {
                    causeName = "transmitter_power_drop";
                    powerReduction = 40 * severity;
                }
                if (activeCause == 2) {
                    causeName = "offered_load";
                    interval = 0.002 / (1 + 19 * severity);
                }
            auto phy = check_and_cast<ControlledPhy *>(gnb->getSubmodule("cellularNic")->getSubmodule("phy"));
            phy->setPowerReduction(powerReduction);
            getParentModule()->getSubmodule("server")->getSubmodule("app", 0)->par("sendInterval").setDoubleValue(interval);
            auto interferer = check_and_cast<simu5g::ExtCell *>(getParentModule()->getSubmodule("interferer"));
            interferer->setBandUtilization(load);
            eventOutput << run << ',' << second << ',' << phase << ',' << load << ',' << lastCommand
                        << ',' << causeName << ',' << severity << std::endl;
            if (!eventOutput) throw cRuntimeError("Cannot write interference event log");
        }
        scheduleAfter(1, tick);
    }
    void unsubscribedFrom(cComponent *component, simsignal_t signal) override {
        for (auto& item : subscriptions)
            if (item.first == component && item.second == signal) item.first = nullptr;
    }
  public:
    ~DownlinkProbe() override {
        for (auto item : subscriptions)
            if (item.first) item.first->unsubscribe(item.second, this);
        cancelAndDelete(tick);
    }
};
Define_Module(DownlinkProbe);
