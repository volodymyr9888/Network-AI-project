"""Versioned simulator recordings and run-level splits. No simulator controls enter features."""
import csv
import hashlib
import json
import math
from pathlib import Path

METRICS = ['throughput_bps', 'sent_bps', 'sinr_db', 'bler_first', 'harq_error_rate',
           'harq_attempts', 'mac_loss_rate', 'cqi', 'allocated_rb', 'delay_ms', 'jitter_ms',
           'modulation_bits', 'code_rate', 'rlc_queue_bytes', 'deadline_missed_packets',
           'delivered_packets', 'pending_packets']


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')


def fingerprint(state):
    return hashlib.sha256(json.dumps(state['measurements'], separators=(',', ':')).encode()).hexdigest()


def read_telemetry(path):
    rows, run_ids = [], set()
    with Path(path).open() as handle:
        for fields in csv.reader(handle):
            if len(fields) == 3 and fields[1] == '0':
                continue
            if len(fields) != 19:
                raise ValueError(f'Incomplete telemetry: {path}')
            run_ids.add(fields[0])
            rows.append([int(fields[1])] + [float(v) if v else None for v in fields[2:]])
    if len(run_ids) != 1:
        raise ValueError('Expected one simulation run per recording')
    return next(iter(run_ids)), rows


def validate_state(state):
    rows = state.get('prepared_measurements', []) + state['measurements']
    if len(state['measurements']) < 10:
        raise ValueError('Recording is too short')
    for i, row in enumerate(rows):
        if len(row) != 18 or any(v is not None and not math.isfinite(v) for v in row):
            raise ValueError('Invalid telemetry shape/nonfinite value')
        if row[1] is None or row[2] is None or row[1] < 0 or row[2] < 0:
            raise ValueError('Missing/negative traffic measurement')
        if i and row[0] != rows[i-1][0] + 1:
            raise ValueError('Nonconsecutive simulation seconds')
    return rows


def load_manifest(path):
    path = Path(path).resolve()
    manifest = json.loads(path.read_text(encoding='utf-8-sig'))
    result, seen, groups = [], {}, {}
    for entry in manifest['runs']:
        if entry['split'] not in ('train', 'validation', 'test'):
            raise ValueError('Unknown split')
        state = json.loads((path.parent / entry['path']).read_text(encoding='utf-8-sig'))
        validate_state(state)
        digest = fingerprint(state)
        if digest != entry['sha256']:
            raise ValueError('Recording changed after manifest creation')
        if digest in seen:
            raise ValueError('Duplicate recording; copies are not independent runs')
        group = str(entry['seed'])
        if group in groups and groups[group] != entry['split']:
            raise ValueError('A simulation seed cannot cross train/validation/test')
        seen[digest], groups[group] = entry['split'], entry['split']
        result.append(dict(entry=entry, state=state, sha256=digest))
    if not result:
        raise ValueError('Empty dataset')
    return result
