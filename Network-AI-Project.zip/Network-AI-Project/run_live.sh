#!/usr/bin/env bash
set -eo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
workspace="${NETWORK_AI_WORKSPACE:-$HOME/default_workspace}"
python_bin="${NETWORK_AI_PYTHON:-$project_dir/.venv/bin/python}"
if [[ ! -x "$python_bin" && -z "${NETWORK_AI_PYTHON:-}" ]]; then
    python_bin="$HOME/network-ai/.venv/bin/python"
    if [[ "${NETWORK_AI_DEVICE:-cpu}" == "cuda" && -x "$HOME/network-ai-gpu/.venv/bin/python" ]]; then
        python_bin="$HOME/network-ai-gpu/.venv/bin/python"
    fi
fi
opp_env_bin="${NETWORK_AI_OPP_ENV:-$HOME/.venv/bin/opp_env}"
if [[ ! -x "$opp_env_bin" ]]; then opp_env_bin="$(command -v opp_env)"; fi
if [[ "${1:-}" != "--inside" ]]; then
    mkdir -p "$project_dir/runs"
    runtime="$(mktemp -d "$project_dir/runs/run-XXXXXXXX")"
    stream="$runtime/downlink.csv"
    touch "$stream"
    port="${NETWORK_AI_PORT:-8766}"
    scenario="${NETWORK_AI_SCENARIO:-VariableRadio}"
    printf -v command 'bash %q --inside %q %q %q' "$project_dir/run_live.sh" \
        "${NETWORK_AI_UI:-Qtenv}" "$runtime" "$scenario"
    ready_file="$runtime/dashboard.ready"
    preparation=()
    if [[ "$scenario" == "VariableRadio" ]]; then
        preparation=(--warmup "$runtime/warmup.csv" --prediction-ready "$runtime/prediction.ready")
    fi
    # opp_env exports Python paths for its own interpreter, not this venv.
    "$python_bin" -E -s "$project_dir/dashboard.py" "$stream" \
        --live --port "$port" --ready-file "$ready_file" --scenario "$scenario" "${preparation[@]}" &
    dashboard_pid=$!
    cleanup() {
        "$python_bin" -E -s "$project_dir/scripts/export_run.py" --port "$port" --output "$runtime/run.json" || true
        kill "$dashboard_pid" 2>/dev/null || true
    }
    trap cleanup EXIT
    trap 'exit 130' INT TERM
    deadline=$((SECONDS + 60))
    until [[ -f "$ready_file" ]]; do
        if ! kill -0 "$dashboard_pid" 2>/dev/null; then
            printf 'Dashboard failed to start. Qtenv was not launched.\n' >&2
            exit 1
        fi
        if (( SECONDS >= deadline )); then
            printf 'Timed out waiting for dashboard startup on port %s.\n' "$port" >&2
            exit 1
        fi
        sleep 0.1
    done
    printf 'Simu5G telemetry: %s\n' "$stream"
    if [[ -f "$HOME/.nix-profile/etc/profile.d/nix.sh" ]]; then source "$HOME/.nix-profile/etc/profile.d/nix.sh"; fi
    cd "$workspace"
    env -u PYTHONPATH -u PYTHONHOME -u PYTHONUSERBASE "$opp_env_bin" run simu5g-1.8.0 -c "$command"
    if [[ "${NETWORK_AI_UI:-Qtenv}" == "Qtenv" ]]; then
        exit
    fi
    printf 'Simulation finished. The dashboard stays open. Press Ctrl+C to stop it.\n'
    wait "$dashboard_pid"
    exit
fi
ui="$2"
runtime="$3"
scenario="$4"
export NETWORK_AI_STREAM="$runtime/downlink.csv"
compiler="${CXX:-clang++}"
# Match release libraries: INET ModuleRefByPar has a different debug class layout.
"$compiler" -std=c++17 -O2 -DNDEBUG -DINET_IMPORT -shared -fPIC -I"$OMNETPP_ROOT/include" -I"$INET_ROOT/src" -I"$SIMU5G_ROOT/src" \
    "$project_dir/live/DownlinkProbe.cc" -o "$runtime/libdownlink_probe.so"

cd "$SIMU5G_ROOT/simulations/nr/standalone"
ned_path="$SIMU5G_ROOT/simulations:$SIMU5G_ROOT/emulation:$SIMU5G_ROOT/src:$INET_ROOT/src:$project_dir/live"
if [[ "$scenario" == "VariableRadio" ]]; then
    NETWORK_AI_STREAM="$runtime/warmup.csv" opp_run -l "$SIMU5G_ROOT/src/simu5g" \
        -u Cmdenv -c RadioWarmup --sim-time-limit=129s --cmdenv-express-mode=true \
        --result-dir="$runtime/warmup-results" --network=LiveStandalone \
        -n "$ned_path" -l "$runtime/libdownlink_probe.so" \
        -f omnetpp.ini -f "$project_dir/live/mobile-downlink.ini" > "$runtime/warmup.log" 2>&1 || {
            cat "$runtime/warmup.log" >&2
            exit 1
        }
    touch "$runtime/warmup.ready"
    deadline=$((SECONDS + 300))
    until [[ -f "$runtime/prediction.ready" ]]; do
        if [[ -f "$runtime/prediction.error" ]]; then
            cat "$runtime/prediction.error" >&2
            exit 1
        fi
        if (( SECONDS >= deadline )); then
            printf 'Initial AI forecast was not ready within 300 seconds. Check the dashboard.\n' >&2
            exit 1
        fi
        sleep 0.2
    done
fi
scheduler=()
if [[ "${NETWORK_AI_REALTIME:-1}" == "1" ]]; then
    scheduler=(--scheduler-class=cRealTimeScheduler)
fi
if [[ "$ui" == "Qtenv" ]]; then
    # Qtenv stores the Step/Run playback limit in the scenario directory.
    # Raise the stock limit while preserving a lower speed selected in the GUI.
    if [[ -f .qtenvrc ]]; then
        sed -i '/^\[RunModeProfiles\]$/,/^\[/ {
            s/^run-max-playback-speed=100$/run-max-playback-speed=1000/
            s/^run-playback-speed=\(100\|300\)$/run-playback-speed=1000/
        }' .qtenvrc
    fi
fi
opp_run -l "$SIMU5G_ROOT/src/simu5g" -u "$ui" -c "$scenario" --sim-time-limit=180s \
    --seed-set="${NETWORK_AI_SEED:-0}" \
    "${scheduler[@]}" \
    --result-dir="$runtime/results" --network=LiveStandalone \
    -n "$ned_path" -l "$runtime/libdownlink_probe.so" \
    -f omnetpp.ini -f "$project_dir/live/mobile-downlink.ini"
