# Rýchly štart / Quick start

## Windows

Use a working WSL2 distribution (default `opp_env`). Open PowerShell **in the downloaded project folder**.
`lab.cmd` starts a child PowerShell process with a process-only execution policy; it does not change your system policy.
For another distribution: `$env:NETWORK_AI_DISTRO = 'Ubuntu'`.
Install [uv](https://docs.astral.sh/uv/getting-started/installation/) **inside WSL** first.

```powershell
.\lab.cmd setup cpu
# NVIDIA GPU alternative: .\lab.cmd setup cuda
.\lab.cmd models
.\lab.cmd doctor --device cpu
.\lab.cmd train examples/demo/manifest.json
.\lab.cmd compare examples/demo/manifest.json --models logistic forest trend persistence always
```

The bundled demo contains real outputs of **Simu5G**, not physical-network measurements.
This workflow does not require installing OMNeT++: it trains and evaluates on saved simulator outputs.
The comparison prints the path to `comparisons/<timestamp>/report.html`; open it in your browser.
The demo-trained warning models can generate many false alarms. Compare them with `always` and
inspect false-positive duration before treating a high event-detection rate as a useful result.
Training creates `models/warnings`. For a second training experiment use a new `--output` directory;
pass the same directory to comparison with `--artifacts`.

To compare pretrained forecasting models on exactly the same held-out data:

```powershell
.\lab.cmd compare examples/demo/manifest.json --models logistic forest persistence always tirex:cpu chronos:cuda
```

Install with `setup cuda` for the CUDA command. Model weights download on first use.
Add `--offline` to require cached weights. TiRex CUDA in this adapter requires Ampere or newer;
on GTX 1650 Ti use `tirex:cpu` and `chronos:cuda`. A GPU is optional for the learned warning models.
Latency depends on hardware and background activity; CPU versus GPU is not a model-only comparison.

## Live Qtenv + dashboard

Install the official [opp_env distribution](https://omnetpp.org/download/) with working WSLg,
then run from the project folder:

```powershell
.\lab.cmd install-simulator
.\lab.cmd live --model tirex --device cpu --warning forest --port 8766
```

Open `http://localhost:8766`. After initialization press Run in Qtenv.
The forecasting model predicts speed; `--warning forest` adds a separate early-warning model using link telemetry.
Use `--warning none` to disable that model or `--warning logistic` to compare another trained model.
The dashboard and interface are Slovak. Closing the browser does not stop the server;
stop the launcher with Ctrl+C before reusing the same port. Do not launch duplicate servers.
Warm-up is a separate 129-second simulation, whose last 128 measurements form the initial context.

Examples:

```powershell
.\lab.cmd live --model chronos --device cuda --warning logistic --cause power --seed 25 --port 8767
.\lab.cmd live --model persistence --device cpu --warning forest --cause interference
```

The dashboard identifies the configured cause from the simulator journal. **The AI does not diagnose that cause.**
It predicts a defined future degradation from past measurements. Abrupt independent disturbances may have no observable precursor.

## Generate new independent experiments

```powershell
.\lab.cmd collect --output datasets/new-study --runs 12 --workers 2 --seed-start 500
.\lab.cmd precursors datasets/new-study/manifest.json
.\lab.cmd train datasets/new-study/manifest.json --output models/new-study
.\lab.cmd compare datasets/new-study/manifest.json --artifacts models/new-study --models logistic forest trend persistence chronos:cuda
```

Collection runs actual Simu5G in accelerated Cmdenv; it may take several minutes per run,
especially with high offered traffic. Python chooses intervention parameters and reads measurements;
it does not generate network telemetry. Each manifest splits **whole runs** into train, validation and test.
Never repeatedly tune against the test split. Generate new seeds for a new final assessment.

## Linux / WSL terminal

Replace `.\lab.cmd` with `bash lab.sh` in every example. Do not type `wsl` inside WSL.
Set `NETWORK_AI_WORKSPACE` if your simulator workspace is not `$HOME/default_workspace`.
The stack is pinned to Simu5G 1.8.0 with the tested INET 4.7.0 and OMNeT++ 6.5.0 APIs.
Keep the simulator workspace on the Linux filesystem for build performance.

## What to compare

- Detected incident beginnings / eligible incident beginnings: did the warning precede the problem?
- False alarm episodes and warning precision: how often does it alarm unnecessarily?
- Warning lead time and p95 inference latency: is the result useful before the deadline?
- Offline quality versus latency-adjusted estimate: the estimate does not replace a live timing test.

See [EVALUATION.md](EVALUATION.md) for the exact protocol and extension points.
