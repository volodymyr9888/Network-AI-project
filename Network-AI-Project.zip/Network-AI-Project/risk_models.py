"""Portable JSON warning models. Only training requires scikit-learn; no pickle loading."""
import json
from pathlib import Path
import numpy as np
from risk_protocol import FEATURE_NAMES, PROTOCOL, features

KINDS = ('logistic','forest')


class WarningModel:
    def __init__(self,artifact):
        if isinstance(artifact,(str,Path)):
            artifact=json.loads(Path(artifact).read_text(encoding='utf-8'))
        if artifact['protocol'] != PROTOCOL or artifact['feature_names'] != FEATURE_NAMES:
            raise ValueError('Warning model protocol/schema mismatch; retrain with this version')
        self.artifact=artifact
        self.threshold=artifact['threshold']

    def probabilities(self, matrix):
        a=self.artifact
        x=np.asarray(matrix,dtype=float)
        x=np.where(np.isfinite(x),x,np.asarray(a['fill']))
        if a['kind']=='logistic':
            x=(x-np.asarray(a['mean']))/np.asarray(a['scale'])
            logits=np.clip(x@np.asarray(a['coef'])+a['intercept'],-700,700)
            return 1/(1+np.exp(-logits))
        # sklearn decision trees compare float32 input values.
        x=x.astype(np.float32)
        out=np.zeros(len(x))
        for tree in a['trees']:
            for i,row in enumerate(x):
                node=0
                while tree['left'][node] != -1:
                    node=tree['left'][node] if float(row[tree['feature'][node]])<=tree['threshold'][node] else tree['right'][node]
                out[i]+=tree['probability'][node]
        return out/len(a['trees'])

    def __call__(self,history):
        return float(self.probabilities([features(history)])[0])


def fit(kind,x,y,validation_x,validation_y,provenance):
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    import sklearn
    if kind not in KINDS or set(y)!={0,1} or set(validation_y)!={0,1}:
        raise ValueError('Training and validation each need normal and pre-onset examples')
    fill=np.asarray([np.median(col[np.isfinite(col)]) if np.isfinite(col).any() else 0 for col in x.T])
    clean=np.where(np.isfinite(x),x,fill)
    a=dict(kind=kind,protocol=PROTOCOL,feature_names=FEATURE_NAMES,fill=fill.tolist(),
           threshold=.5,provenance=provenance,sklearn_version=sklearn.__version__,
           note='Scores are not guaranteed calibrated probabilities. Threshold selected on validation only.')
    if kind=='logistic':
        mean,scale=clean.mean(axis=0),clean.std(axis=0)
        scale[scale<1e-8]=1
        estimator=LogisticRegression(C=.1,class_weight='balanced',max_iter=2000,random_state=0)
        estimator.fit((clean-mean)/scale,y)
        a.update(mean=mean.tolist(),scale=scale.tolist(),coef=estimator.coef_[0].tolist(),intercept=float(estimator.intercept_[0]))
        reference=estimator.predict_proba((clean-mean)/scale)[:,1]
    else:
        estimator=RandomForestClassifier(n_estimators=120,max_depth=5,min_samples_leaf=5,
            class_weight='balanced',random_state=0,n_jobs=2)
        estimator.fit(clean,y)
        trees=[]
        for est in estimator.estimators_:
            tree=est.tree_
            values=tree.value[:,0,:]
            trees.append(dict(left=tree.children_left.tolist(),right=tree.children_right.tolist(),
                feature=tree.feature.tolist(),threshold=tree.threshold.tolist(),
                probability=(values[:,1]/values.sum(axis=1)).tolist()))
        a['trees']=trees
        reference=estimator.predict_proba(clean)[:,1]
    model=WarningModel(a)
    if not np.allclose(model.probabilities(x),reference,atol=1e-7):
        raise ValueError('Portable export differs from training model')
    probabilities=model.probabilities(validation_x)
    choices=[]
    for threshold in np.linspace(.05,.95,19):
        positive=probabilities>=threshold
        tp=int(np.sum(positive & (validation_y==1)))
        fp=int(np.sum(positive & (validation_y==0)))
        fn=int(np.sum(~positive & (validation_y==1)))
        f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0
        choices.append((f1,-fp,float(threshold)))
    best=max(choices)
    a.update(threshold=best[2],validation_f1=best[0],training_examples=len(y),validation_examples=len(validation_y))
    return a
