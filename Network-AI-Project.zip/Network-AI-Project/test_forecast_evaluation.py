import unittest
from forecast_evaluation import evaluate_horizons, evaluate_alerts


class EvaluationTests(unittest.TestCase):
    def test_warning_cannot_use_future_offered_load(self):
        measurements = [[1, 100, 100], [2, 60, 1000]]
        f = dict(issued_at=1, available_at_s=1, values=[60]*5)
        scores = evaluate_alerts(measurements, [f])
        self.assertEqual(scores[0]['fn'], 1)  # Future demand cannot create an earlier warning.
        f['values'][0] = 10
        self.assertEqual(evaluate_alerts(measurements, [f])[0]['tp'], 1)
        f['available_at_s'] = 2
        self.assertEqual(evaluate_alerts(measurements, [f])[0]['tp'], 0)

    def test_matched_pairs_and_strict_deadline(self):
        forecasts = [dict(issued_at=0, available_at_s=1, values=[9, 9, 9, 9, 9], baseline=5)]
        scores = evaluate_horizons([(1, 10), (3, 10), (5, 10)], forecasts)
        self.assertEqual(scores[0]['timely_count'], 0)  # Equal is too late.
        self.assertIsNone(scores[0]['timely_mae'])
        self.assertEqual(scores[1]['timely_mae'], 1)
        self.assertEqual(scores[1]['timely_baseline_mae'], 5)
        self.assertEqual(scores[1]['skill_percent'], 80)

    def test_missing_actual_availability_and_zero_baseline_error(self):
        f = dict(issued_at=0, values=[5]*5, baseline=5)
        scores = evaluate_horizons([(1, 5)], [f])
        self.assertEqual(scores[0]['count'], 1)
        self.assertEqual(scores[0]['timely_count'], 0)
        self.assertEqual(scores[1]['count'], 0)
        f['available_at_s'] = 0
        self.assertIsNone(evaluate_horizons([(1, 5)], [f])[0]['skill_percent'])


if __name__ == '__main__':
    unittest.main()
