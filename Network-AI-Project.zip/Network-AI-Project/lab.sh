#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"
action="${1:-help}"
if [[ $# -gt 0 ]]; then shift; fi
if [[ "$action" == setup ]]; then exec bash scripts/setup.sh "$@"; fi
if [[ "$action" == install-simulator ]]; then exec bash scripts/setup_simulator.sh "$@"; fi
if [[ "$action" == help || "$action" == --help ]]; then
    cat <<'HELP'
Network AI laboratory (run from WSL/Linux; on Windows use .\lab.cmd)
  bash lab.sh setup cpu|cuda
  bash lab.sh install-simulator
  bash lab.sh models
  bash lab.sh doctor --device cuda
  bash lab.sh live --model chronos --device cuda --warning forest
  bash lab.sh collect --output datasets/demo --runs 12 --workers 2
  bash lab.sh precursors datasets/demo/manifest.json
  bash lab.sh train datasets/demo/manifest.json --output models/warnings
  bash lab.sh compare datasets/demo/manifest.json --models logistic forest trend persistence chronos:cuda
Reports: comparisons/<run>/report.html. See QUICKSTART.md for the complete workflow.
HELP
    exit
fi
python_bin="${NETWORK_AI_PYTHON:-$project_dir/.venv/bin/python}"
if [[ ! -x "$python_bin" && -z "${NETWORK_AI_PYTHON:-}" ]]; then
    if [[ -x "$HOME/network-ai-gpu/.venv/bin/python" ]]; then python_bin="$HOME/network-ai-gpu/.venv/bin/python"
    else python_bin="$HOME/network-ai/.venv/bin/python"; fi
fi
if [[ ! -x "$python_bin" ]]; then echo 'First run: bash lab.sh setup cpu (or cuda)' >&2; exit 1; fi
if [[ "$action" == doctor ]]; then exec "$python_bin" -E -s scripts/check_environment.py "$@"; fi
if [[ "$action" == collect ]]; then
    if [[ -f "$HOME/.nix-profile/etc/profile.d/nix.sh" ]]; then source "$HOME/.nix-profile/etc/profile.d/nix.sh"; fi
    opp_bin="${NETWORK_AI_OPP_ENV:-$HOME/.venv/bin/opp_env}"
    if [[ ! -x "$opp_bin" ]]; then opp_bin="$(command -v opp_env)"; fi
    printf -v command '%q ' "$python_bin" -E -s "$project_dir/collect_simulations.py" "$@"
    cd "${NETWORK_AI_WORKSPACE:-$HOME/default_workspace}"
    exec env -u PYTHONPATH -u PYTHONHOME -u PYTHONUSERBASE "$opp_bin" run simu5g-1.8.0 -c "cd $(printf %q "$project_dir") && $command"
fi
if [[ "$action" == live ]]; then exec "$python_bin" -E -s lab_live.py "$@"; fi
exec "$python_bin" -E -s warning_lab.py "$action" "$@"
