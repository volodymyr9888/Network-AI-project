# Early-warning protocol v1

The target is **a new sustained delivery degradation within the next five simulation seconds**.
At least two consecutive seconds must have received throughput below 50% of sent traffic.
This is an operational benchmark definition, not a universal definition of radio interference.
Low received traffic alone cannot identify the physical cause.

Prediction origins require 128 past measurements and three healthy recent seconds with positive sent traffic.
Already ongoing degradation is excluded. The complete five-second future plus confirmation must exist for scoring.
Right-edge unconfirmed drops are excluded. True event labels use future measurements only in evaluation,
never in model features. We count an event as detected if any warning issued in its preceding five-second window
was available before onset. Lead time uses the earliest qualifying warning.
Events without an eligible origin are reported separately as all-confirmed versus eligible event counts in JSON.

The learned classifiers use 10-second summaries (last, mean, std, slope, delta, missing fraction) of throughput,
sent traffic, SINR, BLER, HARQ errors/attempts, MAC loss, CQI, allocated RBs, delay, jitter,
modulation, code rate, RLC queue, deadline misses, delivered/pending packet counts and delivery ratio.
These measurements are from the probe, at the layers described in its source; they are not all independently causal.
Missing metrics remain missing and are imputed using training medians.
No timestamps, seed, intervention plan, cause labels or future control settings enter the feature vector.
RLC backlog and deteriorating SINR may provide precursors, but usefulness must be measured on held-out runs.

Logistic regression and random forest learn normal versus pre-onset windows from the training split.
Thresholds maximize decision F1 on validation only. Scores are **not calibrated probabilities**.
Temporal windows overlap; they are not independent samples. Whole simulations, rather than rows, are split.
Fingerprint checks reject copied runs and train/test overlap. Common calibration history is deliberately shared
across runs; it is a separate healthy calibration experiment, not part of the held-out outcomes.

TiRex / Chronos predict throughput from the past 128 samples and supported past covariates.
Their warning is `any predicted future throughput < 0.5 * sent traffic at forecast origin`.
Future sent traffic is unknown and never used to generate this warning. Persistence and ten-point linear trend
use the same conversion. Learned classification and this forecast conversion solve the same event task
through different mechanisms; report them separately alongside accuracy and cost.

`precursors` reports descriptive standardized feature differences on **training only**.
They are neither causal explanations nor statistical significance tests.
Test data must not be used to choose a new threshold/model and then reused as an independent final test.
The demo is small and uses a single topology and limited disturbance family; no general-real-network claim is supported.
The `always` baseline warns at every eligible healthy origin. It demonstrates why detecting every event
is insufficient: compare warning precision and false-positive seconds, not only incident recall or episode counts.
An uninterrupted false alarm counts as one episode; its duration is therefore shown separately.

## Time semantics

Offline comparison evaluates every common eligible origin. p95 includes feature construction and inference,
after model warm-up, not weight download. The latency-adjusted column estimates availability as origin + measured latency
at 1x simulation speed. It does not model queues, skipping, Qtenv or polling delays.
The live application separates telemetry reception from foundation-model inference and uses the latest pending context.
Slow inference can skip origins; inspect exported `skipped_predictions`, `available_at_s` and warning records.
Availability timestamps have simulation-second granularity; they are not subsecond end-to-end latency measurements.

## Add another model

1. Throughput model: extend `model_adapters.Predictor` and `MODELS`, returning exactly five finite median values in bit/s.
   Input is 128 past target values plus explicitly supported past covariates; no future values. Report real device/model revision.
2. Register its name in `warning_lab.compare`, `lab_live.py` choices and dashboard launch options.
3. Warning classifier: extend `risk_models` training and portable JSON inference, keep schema/protocol checks,
   and use validation-only threshold selection. Register in `KINDS` and the live launcher choices.
4. Add adapter-contract tests, compare on the same manifest, and retain per-run outputs.

Do not replace an unavailable GPU with CPU silently. Do not load untrusted pickle models.
JSON warning artifacts contain learned arrays and protocol metadata, not executable pickles.

## Publication

`scripts/package_source.py` builds `dist/Network-AI-Project.zip` from an explicit source allowlist plus the public demo.
Raw local runs, downloaded model weights, environments and personal datasets are excluded.
GitHub Actions runs unit tests without model downloads. Choose an appropriate project license with your team
before public release; third-party simulators and model weights retain their own licenses and are not bundled.
This preparation does not create or publish a GitHub repository.
