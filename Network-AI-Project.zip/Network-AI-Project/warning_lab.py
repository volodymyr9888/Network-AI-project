"""Train, inspect and compare onset warnings on whole held-out simulator runs."""
import argparse
import gc
import html
import json
from pathlib import Path
import time
import platform
import sys
import numpy as np
from lab_data import dump, load_manifest
from risk_protocol import PROTOCOL, FEATURE_NAMES, features, samples, evaluate, onsets
from risk_models import WarningModel, fit, KINDS


def training_data(runs, split):
    examples=[(features(history),label) for run in runs if run['entry']['split']==split
              for _,history,label in samples(run['state'])]
    if not examples:
        raise ValueError(f'No eligible examples in {split}')
    return np.asarray([x for x,_ in examples]),np.asarray([y for _,y in examples])


def train(args):
    runs=load_manifest(args.manifest)
    x,y=training_data(runs,'train')
    vx,vy=training_data(runs,'validation')
    provenance={split:[r['sha256'] for r in runs if r['entry']['split']==split]
                for split in ('train','validation')}
    output=Path(args.output)
    if output.exists():
        raise ValueError('Output already exists; choose a new --output directory')
    artifacts=[fit(kind,x,y,vx,vy,provenance) for kind in args.models]
    output.mkdir(parents=True,exist_ok=False)
    for kind,artifact in zip(args.models,artifacts):
        dump(output/f'{kind}.json',artifact)
        print(f'{kind}: train={len(y)} ({int(y.sum())} positive), validation={len(vy)}, '
              f'threshold={artifact["threshold"]:.2f}, validation F1={artifact["validation_f1"]:.3f}',flush=True)
    print('Models:',output)


def aggregate(scores):
    keys=('events','all_confirmed_events','detected_events','false_alarm_episodes','decisions','tp','fp','fn','tn')
    out={k:sum(s[k] for s in scores) for k in keys}
    out['event_recall']=out['detected_events']/out['events'] if out['events'] else None
    out['precision']=out['tp']/(out['tp']+out['fp']) if out['tp']+out['fp'] else None
    lead_count=sum(s['detected_events'] for s in scores if s['mean_lead_s'] is not None)
    out['mean_lead_s']=sum(s['mean_lead_s']*s['detected_events'] for s in scores if s['mean_lead_s'] is not None)/lead_count if lead_count else None
    normal_minutes=(out['fp']+out['tn'])/60
    out['false_episodes_per_normal_minute']=out['false_alarm_episodes']/normal_minutes if normal_minutes else None
    return out


def html_report(report,path):
    def number(v,scale=1):return '—' if v is None else f'{v*scale:.2f}'
    rows=[]
    for r in report['results']:
        name=html.escape(r['name'])
        if 'error' in r:
            rows.append(f'<tr><td>{name}</td><td colspan="7">{html.escape(r["error"])}</td></tr>')
            continue
        q=r['quality']; d=r['deadline_estimate']
        rows.append(f'<tr><td>{name}</td><td>{q["detected_events"]}/{q["events"]}</td>'
            f'<td>{number(q["event_recall"],100)} %</td><td>{q["false_alarm_episodes"]} / {q["fp"]} s</td>'
            f'<td>{number(q["precision"],100)} %</td><td>{number(q["mean_lead_s"])}</td>'
            f'<td>{number(r["p95_ms"])}</td><td>{number(d["event_recall"],100)} %</td></tr>')
    page='''<!doctype html><html lang="sk"><meta charset="utf-8"><title>Laboratórium včasného varovania</title>
<style>body{font:16px system-ui;background:#0c121d;color:#e8edf5;max-width:1250px;margin:35px auto;padding:20px}p{line-height:1.6;color:#b5c5da}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:12px;border-bottom:1px solid #354962}a{color:#9db7ff}</style>
<h1>Ktorý model včas predpovedá začiatok problému?</h1>
<p>Spoločný test: príjem pod 50 % odoslaného toku aspoň 2 sekundy. Varovanie najviac 5 sekúnd vopred,
po aspoň 3 zdravých sekundách. Prebiehajúci výpadok sa nepočíta ako úspešná predikcia začiatku.</p>
<table><tr><th>Model / zariadenie</th><th>Predpovedané začiatky</th><th>Záchyt</th><th>Falošné epizódy / sekundy</th><th>Presnosť varovaní*</th><th>Predstih, s</th><th>p95, ms</th><th>Záchyt po odhade latencie</th></tr>'''
    page+=''.join(rows)+'</table>'
    page+='<h2>Kedy prišlo varovanie?</h2><p>Každý riadok: 0–180 s. Červená čiara = potvrdený začiatok problému. Žltý bod = vydané varovanie. Príčina je nastavenie simulátora, nie diagnóza AI. Čas na grafe je čas vydania; latencia je hodnotená samostatne.</p>'
    for result in report['results']:
        if 'error' in result: continue
        page+=f'<h3>{html.escape(result["name"])}</h3>'
        for run in result['runs']:
            page+=f'<p>Seed {run["seed"]} · {html.escape(run["cause"])} · zachytené {run["quality"]["detected_events"]}/{run["quality"]["events"]}</p>'
            page+='<svg viewBox="0 0 940 52" role="img" aria-label="Časová os varovaní" style="width:100%;background:#152234"><path d="M20 25H920" stroke="#63758f"/>'
            for t in run['onsets']:
                x=20+t*5
                page+=f'<path d="M{x} 5V40" stroke="#ff7777" stroke-width="2"><title>Začiatok: {t} s</title></path>'
            for t in run['alarm_origins']:
                page+=f'<circle cx="{20+t*5}" cy="25" r="3" fill="#ffd07c"><title>Varovanie: {t} s</title></circle>'
            page+='<text x="20" y="49" fill="#b5c5da" font-size="10">0 s</text><text x="890" y="49" fill="#b5c5da" font-size="10">180 s</text></svg>'
    page+=f'<p>Testovacie behy: {report["test_runs"]}. Rovnaké rozhodovacie okná pre všetky úspešné modely. Testovacie dáta sa nepoužili na učenie ani výber prahu.</p>'
    page+='<p>Vysoký záchyt s mnohými falošnými varovaniami nestačí. Kontrolný model <code>always</code> varuje pri každom vhodnom meraní. Porovnajte aj presnosť a trvanie falošných varovaní.</p>'
    page+='''<p>*Presnosť varovaní je podiel správnych pozitívnych rozhodnutí. Falošné epizódy spájajú po sebe idúce falošné varovania.
Predstih používa najskoršie správne varovanie, nie iba posledný prognostický bod. Záchyt počíta incidenty, nie sekundy výpadku.</p>
<p>Offline kvalita predpokladá okamžitú dostupnosť. Posledný stĺpec len odhaduje vplyv nameraného času inferencie pri rýchlosti 1×;
nejde o živý test frontu, Qtenv alebo sieťových oneskorení. Žiadne automatické označenie univerzálneho víťaza:
porovnajte záchyt spolu s falošnými varovaniami a latenciou.</p><p><a href="report.json">Úplné metriky, protokol, identifikátory a jednotlivé behy</a></p></html>'''
    path.write_text(page,encoding='utf-8')


def compare(args):
    runs=load_manifest(args.manifest)
    tests=[r for r in runs if r['entry']['split']=='test']
    if not tests:raise ValueError('No held-out test runs')
    tasks=[(r,list(samples(r['state']))) for r in tests]
    if any(not ts for _,ts in tasks):raise ValueError('Test run without eligible windows')
    output=Path(args.output) if args.output else Path('comparisons')/time.strftime('%Y%m%d-%H%M%S')
    output.mkdir(parents=True,exist_ok=False)
    report=dict(protocol=PROTOCOL,test_runs=len(tests),test_hashes=[r['sha256'] for r in tests],results=[],
        environment=dict(python=sys.version,platform=platform.platform(),numpy=np.__version__),
        timing_note='Sequential model measurements after warm-up. Background workloads can affect latency.')
    failed=False
    for spec in args.models:
        engine=None
        name,_,device=spec.partition(':')
        device=device or 'cpu'
        try:
            if name in KINDS:
                if device!='cpu':raise ValueError('Warning models run on CPU; use logistic or forest without :cuda')
                engine=WarningModel(Path(args.artifacts)/f'{name}.json')
                used=set(sum(engine.artifact['provenance'].values(),[]))
                if any(r['sha256'] in used for r in tests):
                    raise ValueError('Train/test leakage: model has seen a requested test run')
                provenance=engine.artifact['provenance']
                threshold=engine.threshold
            elif name in ('tirex','chronos','persistence'):
                from model_adapters import Predictor
                engine=Predictor(name,device,args.offline)
                provenance=engine.metadata();threshold=.5
                _,first,_=tasks[0][1][0]
                for _ in range(2):forecast(engine,first)
            elif name in ('trend','always'):
                if device!='cpu':raise ValueError('Trend baseline runs on CPU')
                provenance=dict(model='linear-throughput-trend' if name=='trend' else 'always-warn-healthy',device='cpu');threshold=.5
            else:raise ValueError(f'Unknown model {name}; use models command')
            all_records=[]; quality=[]; deadlines=[]; details=[]
            for run,decisions in tasks:
                records=[]
                for issued,history,label in decisions:
                    started=time.perf_counter()
                    if name=='always':
                        score=1.
                    elif name in KINDS:
                        score=engine(history)
                    else:
                        values=forecast(engine,history) if engine else trend(history)
                        score=float(any(v<.5*history[-1][2] for v in values))
                    records.append(dict(issued_at=issued,label=label,score=score,alarm=score>=threshold,
                        latency_ms=(time.perf_counter()-started)*1000))
                quality.append(evaluate(run['state'],records))
                deadlines.append(evaluate(run['state'],records,True))
                details.append(dict(seed=run['entry']['seed'],sha256=run['sha256'],quality=quality[-1],deadline_estimate=deadlines[-1],
                    cause=run['state'].get('experiment',{}).get('cause','unknown'),
                    onsets=onsets(run['state'].get('prepared_measurements',[])+run['state']['measurements']),
                    alarm_origins=[r['issued_at'] for r in records if r['alarm']]))
                all_records.extend(records)
                dump(output/f'{name}-{device}-seed-{run["entry"]["seed"]}.json',records)
            times=[r['latency_ms'] for r in all_records]
            result=dict(name=spec,metadata=provenance,threshold=threshold,quality=aggregate(quality),
                deadline_estimate=aggregate(deadlines),mean_ms=float(np.mean(times)),p95_ms=float(np.percentile(times,95)),runs=details)
            print(f'{spec}: events {result["quality"]["detected_events"]}/{result["quality"]["events"]}, '
                  f'false episodes {result["quality"]["false_alarm_episodes"]}, p95 {result["p95_ms"]:.1f} ms',flush=True)
        except Exception as exc:
            result=dict(name=spec,error=str(exc));failed=True
            print(spec,'FAILED:',exc,flush=True)
        finally:
            del engine;gc.collect()
            import torch
            if torch.cuda.is_available():torch.cuda.empty_cache()
        report['results'].append(result)
        dump(output/'report.json',report);html_report(report,output/'report.html')
    print('Open:',output/'report.html',flush=True)
    if failed:raise SystemExit(1)


def forecast(engine,history):
    context=[r[1] for r in history]
    cov=np.asarray([[np.nan if r[i] is None else r[i] for r in history] for i in range(2,18)],dtype=np.float32)
    cov=cov[~np.isnan(cov).all(axis=1)]
    return engine(context,cov if len(cov) else None)


def trend(history):
    y=np.asarray([r[1] for r in history[-10:]])
    slope,intercept=np.polyfit(np.arange(len(y)),y,1)
    return (intercept+slope*np.arange(10,15)).tolist()


def precursors(args):
    runs=load_manifest(args.manifest)
    x,y=training_data(runs,'train')
    if set(y)!={0,1}:raise ValueError('Need both normal and pre-onset training windows')
    stats=[]
    for i,name in enumerate(FEATURE_NAMES):
        pos=x[y==1,i];neg=x[y==0,i]
        pos=pos[np.isfinite(pos)];neg=neg[np.isfinite(neg)]
        if len(pos)<3 or len(neg)<3:continue
        std=np.std(np.r_[pos,neg])
        if std<1e-8:continue
        stats.append(dict(feature=name,pre_onset_mean=float(pos.mean()),normal_mean=float(neg.mean()),
                          standardized_difference=float((pos.mean()-neg.mean())/std)))
    stats.sort(key=lambda r:abs(r['standardized_difference']),reverse=True)
    result=dict(protocol=PROTOCOL,split='train',positive_windows=int(y.sum()),normal_windows=int((y==0).sum()),
        warning='Descriptive associations in dependent windows, not significance tests or proof of causality.',features=stats)
    dump(args.output,result)
    for r in stats[:10]:print(r['feature'],round(r['standardized_difference'],3))
    print('Saved:',args.output)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest='command',required=True)
    commands.add_parser('models',help='List supported model/device combinations')
    p=commands.add_parser('train');p.add_argument('manifest',type=Path)
    p.add_argument('--output',default='models/warnings');p.add_argument('--models',nargs='+',choices=KINDS,default=list(KINDS))
    p=commands.add_parser('compare');p.add_argument('manifest',type=Path)
    p.add_argument('--models',nargs='+',default=['logistic','forest','trend','persistence','always'])
    p.add_argument('--artifacts',default='models/warnings');p.add_argument('--output');p.add_argument('--offline',action='store_true')
    p=commands.add_parser('precursors');p.add_argument('manifest',type=Path);p.add_argument('--output',default='comparisons/precursors.json')
    args=parser.parse_args()
    if args.command=='models':
        print('logistic, forest: trained onset-warning score, CPU, JSON artifacts required\n'
              'trend, persistence, always: no-training baselines, CPU\n'
              'chronos:cpu / chronos:cuda: speed forecast converted to onset warning\n'
              'tirex:cpu / tirex:cuda: same; CUDA requires Ampere+ in this adapter')
    else:globals()[args.command](args)


if __name__=='__main__':main()
