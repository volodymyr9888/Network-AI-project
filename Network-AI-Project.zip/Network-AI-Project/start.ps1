param(
    [ValidateSet('tirex','chronos','persistence')][string]$Model = 'tirex',
    [ValidateSet('cpu','cuda','auto')][string]$Device = 'cpu',
    [ValidateSet('interference','power','load')][string]$Cause = 'interference',
    [ValidateRange(1024,65535)][int]$Port = 8766,
    [int]$Seed = 0,
    [string]$Distro = 'opp_env',
    [switch]$Headless
)
$ErrorActionPreference = 'Stop'
$linuxProject = (& wsl -d $Distro -- wslpath -u $PSScriptRoot).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Cannot resolve project directory in WSL.' }
$simulationUi = if ($Headless) { 'Cmdenv' } else { 'Qtenv' }
& wsl -d $Distro -- env "NETWORK_AI_MODEL=$Model" "NETWORK_AI_DEVICE=$Device" `
    "NETWORK_AI_CAUSE=$Cause" "NETWORK_AI_PORT=$Port" "NETWORK_AI_SEED=$Seed" `
    "NETWORK_AI_UI=$simulationUi" bash "$linuxProject/run_live.sh"
exit $LASTEXITCODE
