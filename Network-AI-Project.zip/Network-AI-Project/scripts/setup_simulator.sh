#!/usr/bin/env bash
set -euo pipefail
if [[ -f "$HOME/.nix-profile/etc/profile.d/nix.sh" ]]; then source "$HOME/.nix-profile/etc/profile.d/nix.sh"; fi
opp_bin="${NETWORK_AI_OPP_ENV:-$HOME/.venv/bin/opp_env}"
if [[ ! -x "$opp_bin" ]]; then opp_bin="$(command -v opp_env || true)"; fi
if [[ -z "$opp_bin" ]]; then
    echo 'Install the official opp_env WSL distribution first: https://omnetpp.org/download/' >&2
    exit 1
fi
workspace="${NETWORK_AI_WORKSPACE:-$HOME/default_workspace}"
mkdir -p "$workspace"
cd "$workspace"
if [[ ! -e .opp_env_workspace ]]; then "$opp_bin" init; fi
exec env -u PYTHONPATH -u PYTHONHOME -u PYTHONUSERBASE "$opp_bin" install simu5g-1.8.0
