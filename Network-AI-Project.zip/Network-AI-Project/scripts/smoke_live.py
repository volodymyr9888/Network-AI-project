"""Exercise an explicitly selected TEST server; never run against a user's active experiment."""
import argparse
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--port', type=int, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
url = f'http://localhost:{args.port}'
plan = [(5, 'transmitter_power_drop', 1.0, 10),
        (22, 'offered_load', .5, 10), (40, 'external_radio_interference', .95, 10)]
sent = []
deadline = time.monotonic() + 600
while time.monotonic() < deadline:
    with urlopen(url + '/api/state', timeout=5) as response:
        state = json.load(response)
    if state.get('error') or state.get('prediction_error'):
        raise RuntimeError(state.get('error') or state.get('prediction_error'))
    if plan and state['count'] >= plan[0][0]:
        _, cause, load, duration = plan.pop(0)
        body = dict(run_id=state['run_id'], mode='manual', cause=cause, load=load, duration=duration)
        request = Request(url+'/api/interference', data=json.dumps(body).encode(),
                          headers={'Content-Type':'application/json'})
        with urlopen(request, timeout=5) as response:
            command = json.load(response)
        sent.append((cause, command['command_id']))
        print('Requested', cause, command, 'at', state['count'], flush=True)
    if state['count'] == 180 and not state['busy'] and state['forecasts'][-1]['issued_at'] == 180:
        events = state['interference_events']
        for cause, command in sent:
            assert any(e['cause'] == cause and e['command_id'] == command for e in events)
        assert len(sent) == 3
        assert len(state['measurements']) == 180
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(state, indent=2), encoding='utf-8')
        print('PASS: three acknowledged causes, 180 measurements, final prediction; saved', args.output, flush=True)
        break
    time.sleep(.25)
else:
    raise TimeoutError('Live smoke test did not complete')
