#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
mode="${1:-cpu}"
case "$mode" in
    cpu) index=https://download.pytorch.org/whl/cpu ;;
    cuda) index=https://download.pytorch.org/whl/cu126 ;;
    *) echo 'Usage: bash scripts/setup.sh cpu|cuda'; exit 2 ;;
esac
uv_bin="${UV_BIN:-$(command -v uv || true)}"
if [[ -z "$uv_bin" && -x "$HOME/.local/bin/uv" ]]; then uv_bin="$HOME/.local/bin/uv"; fi
if [[ -z "$uv_bin" ]]; then echo 'Install uv first: https://docs.astral.sh/uv/getting-started/installation/'; exit 1; fi
venv="${NETWORK_AI_VENV:-$project_dir/.venv}"
if [[ ! -x "$venv/bin/python" ]]; then "$uv_bin" venv --python 3.12 "$venv"; fi
"$uv_bin" pip install --python "$venv/bin/python" 'torch==2.8.0' --index-url "$index"
"$uv_bin" pip install --python "$venv/bin/python" -r "$project_dir/requirements.txt"
"$venv/bin/python" -E -s "$project_dir/scripts/check_environment.py" --device "$mode"
echo "Ready. Python: $venv/bin/python"
