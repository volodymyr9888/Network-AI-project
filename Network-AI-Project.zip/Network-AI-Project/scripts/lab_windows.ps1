$ErrorActionPreference = 'Stop'
$projectDirectory = Split-Path -Parent $PSScriptRoot
$distribution = if ($env:NETWORK_AI_DISTRO) { $env:NETWORK_AI_DISTRO } else { 'opp_env' }
& wsl.exe -d $distribution --cd $projectDirectory -- bash lab.sh @args
exit $LASTEXITCODE
