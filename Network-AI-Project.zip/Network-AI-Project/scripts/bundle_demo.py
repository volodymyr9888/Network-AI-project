"""Bundle only validated generated recordings, never raw runtime directories or weights."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lab_data import load_manifest, dump

parser=argparse.ArgumentParser()
parser.add_argument('manifest',type=Path)
parser.add_argument('--output',type=Path,default=Path('examples/demo'))
args=parser.parse_args()
runs=load_manifest(args.manifest)
args.output.mkdir(parents=True,exist_ok=False)
manifest=dict(version=1,source='Simu5G',runs=[],
    note='Generated simulator measurements; whole-run split. Common separate healthy calibration history. Not physical-network traces.')
for i,run in enumerate(runs):
    entry=dict(run['entry'],path=f'run-{i:02d}.json')
    # Preserve only fields used for this reproducible benchmark.
    original=run['state']
    state={k:original[k] for k in ('prepared_measurements','measurements','experiment')}
    if state['experiment'].get('source')!='Simu5G':
        raise ValueError('Only generated Simu5G recordings belong in the public demo')
    dump(args.output/entry['path'],state)
    manifest['runs'].append(entry)
dump(args.output/'manifest.json',manifest)
print(args.output/'manifest.json')
