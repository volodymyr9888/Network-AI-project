"""Integration check with an existing real simulator recording, not a wall-clock/live benchmark."""
import argparse
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dashboard import Replay
from model_adapters import Predictor
from risk_models import WarningModel
from lab_data import validate_state
from risk_protocol import eligible

parser=argparse.ArgumentParser()
parser.add_argument('recording',type=Path)
parser.add_argument('--model',type=Path,default=Path('models/warnings/forest.json'))
args=parser.parse_args()
state=json.loads(args.recording.read_text())
all_rows=validate_state(state)
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp); warm=root/'warmup.csv'; stream=root/'downlink.csv'
    def line(t,row):
        return '1,'+str(t)+','+','.join('' if v is None else str(int(v)) if i==0 else str(v)
                                       for i,v in enumerate(row[1:]))+'\n'
    warm.write_text(''.join(line(i+1,r) for i,r in enumerate(state['prepared_measurements'])))
    warm.with_suffix('.ready').touch()
    stream.write_text('1,0,0\n'+''.join(line(r[0],r) for r in state['measurements']))
    replay=Replay(stream,live=True,warmup=warm)
    replay.warning_model=WarningModel(args.model)
    errors=[]
    def run():
        try:replay.follow(Predictor('persistence'))
        except Exception as exc:errors.append(exc)
    threading.Thread(target=run,daemon=True).start()
    until=time.monotonic()+30
    expected=sum(eligible(all_rows[max(0,i-127):i+1]) for i in range(127,len(all_rows)))
    while time.monotonic()<until:
        if errors:raise errors[0]
        if replay.count==180 and len(replay.warning_records)==expected:break
        time.sleep(.05)
    else:raise TimeoutError('Reader or warning model did not finish recorded telemetry')
    result=replay.snapshot()
    assert result['warning_model']['kind']==replay.warning_model.artifact['kind']
    assert result['warning_scores'] is not None
    print(json.dumps(dict(measurements=replay.count,warning_decisions=expected,
                          warning_scores=result['warning_scores']),indent=2))
