import argparse
import json
import sys
import numpy as np
import torch

parser = argparse.ArgumentParser()
parser.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
args = parser.parse_args()
if args.device == 'cuda' and not torch.cuda.is_available():
    raise SystemExit('CUDA unavailable: check NVIDIA driver, WSL GPU access and PyTorch CUDA build.')
device = args.device
x = torch.ones(2, device=device)
assert (x + x).sum().item() == 4
print(json.dumps(dict(python=sys.executable, numpy=np.__version__, numpy_path=np.__file__,
    torch=torch.__version__, device=device,
    gpu=torch.cuda.get_device_name(0) if device == 'cuda' else None)))
