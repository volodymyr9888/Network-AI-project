"""Save a dashboard snapshot before shutdown; raw telemetry remains if this fails."""
import argparse
from pathlib import Path
from urllib.request import urlopen

parser = argparse.ArgumentParser()
parser.add_argument('--port', type=int, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
try:
    with urlopen(f'http://localhost:{args.port}/run.json', timeout=5) as response:
        data = response.read()
    args.output.write_bytes(data)
    print('Saved run:', args.output)
except Exception as exc:
    print('Could not save dashboard snapshot; raw simulator files remain:', exc)
    raise SystemExit(1)
