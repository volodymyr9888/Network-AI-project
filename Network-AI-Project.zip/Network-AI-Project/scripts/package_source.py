"""Build a source-only archive; exclude recordings, weights, virtualenvs and Git metadata."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
allowed = {'.py', '.sh', '.ps1', '.cmd', '.md', '.txt', '.html', '.cc', '.h', '.ned', '.ini', '.yml'}
files = [p for p in root.iterdir() if p.is_file() and
         (p.suffix in allowed or p.name in {'.gitignore', '.gitattributes'})]
for directory in ('live', 'scripts', '.github'):
    files.extend(p for p in (root / directory).rglob('*') if p.is_file() and p.suffix in allowed)
output = root / 'dist' / 'Network-AI-Project.zip'
files.extend(p for p in (root / 'examples').rglob('*') if p.is_file() and p.suffix in {'.json', '.md', '.html'})
output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, Path('Network-AI-Project') / path.relative_to(root))
print(output, f'({len(files)} source files)')
